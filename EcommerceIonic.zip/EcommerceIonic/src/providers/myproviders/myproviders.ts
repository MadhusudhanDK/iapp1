import { HttpClient, HttpRequest, HttpHandler } from '@angular/common/http';
import { Injectable, NgZone } from '@angular/core';
import { App,LoadingController, Platform } from "ionic-angular";
import 'rxjs/add/operator/catch';
import { Observable } from "rxjs/Rx"
import { NavController } from "ionic-angular/index";
import { RestProvider } from '../../providers/rest/rest';
import { AlertController } from 'ionic-angular';
import { LoginPage } from '../../pages/login/login';
import 'rxjs/add/operator/map';
import { SpeechRecognition } from '@ionic-native/speech-recognition';
import { AngularFirestore } from 'angularfire2/firestore';
import { Firebase } from '@ionic-native/firebase';
import { HttpHeaders,HttpParams } from '@angular/common/http';
import { Http, Headers,RequestOptions, RequestMethod } from '@angular/http';
import { ProductdetailPage } from '../../pages/productdetail/productdetail';
import { ProductgridPage } from '../../pages/productgrid/productgrid';



/*
  Generated class for the MyprovidersProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class MyprovidersProvider {

  private apiUrl = '';
  private navCtrl: NavController;
  countries: string[];
  isListening: boolean = false;
  matches: Array<String>;
  errorMessage: string;
  options : any;
  public myValue;
  seachInput;
  searchResult;

 
  constructor(public http: HttpClient,  public loadingCtrl: LoadingController,  public rest: RestProvider,public alertCtrl : AlertController, public speech: SpeechRecognition, private zone: NgZone,public firebaseNative: Firebase,public afs: AngularFirestore,private platform: Platform,public http2: Http) {
    console.log('Hello MyprovidersProvider Provider');
  }

getCountries(url): Observable<string[]> { 
  if(url == 'test'){
    this.apiUrl = 'https://restcountries.eu/rest/v2/all';         
  }
  else if(url == 'myaccount'){
    this.apiUrl = 'https://jsonplaceholder.typicode.com/comments';         

  }
  else if(url == 'savedcart'){
    this.apiUrl =  'https://jsonplaceholder.typicode.com/users';
  }
  else if(url == 'slider'){
    this.apiUrl =  'https://jsonplaceholder.typicode.com';
  }
  return this.http.get(this.apiUrl) 
                    .map(this.extractData)
                    .catch(this.handleError);
  }
// getCheckoutData(path){
//     return this.http.get(path,{headers: {'Authorization': 'Bearer '+window.localStorage.getItem("ACCESS_TOKEN")}}) 
//     .map(this.extractData).catch(this.handleError);
//  }
getContent(path){
    return this.http.get(window.localStorage.getItem("APIURL")+path,{headers: {'Authorization': 'Bearer '+window.localStorage.getItem("ACCESS_TOKEN")}}) 
    .map(this.extractData).catch(this.handleError);
 }
postContent(path,data){
console.log("cart");
const headers  = new HttpHeaders();
headers.set('Content-Type','application/json');
let body: HttpParams = new HttpParams();
const options = {headers: headers};
return this.http.post(window.localStorage.getItem("APIURL")+path,data,{headers: {'Content-Type':'application/json','Authorization': 'Bearer '+window.localStorage.getItem("ACCESS_TOKEN")}}) 
                  .map(this.extractData)
                  .catch(this.handleError)
                  
 }

 deleteContent(path){
   return this.http.delete(window.localStorage.getItem("APIURL")+path,{headers: {'Authorization': 'Bearer '+window.localStorage.getItem("ACCESS_TOKEN")}}) 
   .map(this.extractData).catch(this.handleError);
}
  getAccessToken(url){ 
    const headers  = new HttpHeaders();
    let body: HttpParams = new HttpParams();
    body = body.append('grant_type', 'password');
    body = body.append('username', window.localStorage.getItem("AUTHUSER"));
    body = body.append('password', window.localStorage.getItem("AUTHPWD"));
    const options = {headers: headers};
    return this.http.post(url,body,{headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8','Authorization':'Basic NDg3MDllZmUtZjQ3ZS00MTIwLWJlMTYtYjFkOTliNDM1MGM3Ok1lRVI0UHRMPWpRTTJCNiM='}}) 
                      .map(this.extractData)
                      .catch(this.handleError);
    }

  refreshToken(url){
    console.log("inisde refresh token");
    const headers  = new HttpHeaders();
    let body: HttpParams = new HttpParams();
    body = body.append('grant_type', 'refresh_token');
    body = body.append('refresh_token', window.localStorage.getItem("REFRESH_TOKEN"));
    const options = {headers: headers};
    return this.http.post(window.localStorage.getItem("APIURL")+"/aas/oauth/token",body,{headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8','Authorization':'Basic NDg3MDllZmUtZjQ3ZS00MTIwLWJlMTYtYjFkOTliNDM1MGM3Ok1lRVI0UHRMPWpRTTJCNiM='}}) 
                      .map(this.extractData)
                      .catch(this.handleError)
     
  } 

  private extractData(res: any) {
    let body = res;
    return body || { };
  }

  private handleError (error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
      const err = error || '';
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } 
    else if (error && error.status === 400 && error.error && error.error.error === 'invalid_grant') {
      //return this.logoutUser();
   }
   else if (error && error.status === 401 && error.error && error.error.error === 'invalid_token') {
    // this.isRefreshingToken = false;
    if(error.error.error_description.indexOf('Access token expired') >= 0){
      errMsg = error.message ? error.message : error.toString();       
    return Observable.throw("AccessTokenExpired");

    }

    if(error.error.error_description.indexOf('Invalid refresh token') >= 0){
      errMsg = error.message ? error.message : error.toString();       
    return Observable.throw("RefreshTokenExpired");

    }
  }
  else if(error.status === 503 && error.error.indexOf('html') >= 0){
    return Observable.throw(error.error);
   }
   else if(error.status === 404){
    console.log("noResource");
   return Observable.throw("noResource");
  }
    else {
      errMsg = error.message ? error.message : error.toString();
    }
   return Observable.throw(errMsg);
    // return Observable.throw(error);
  }
   // global methods
public alert(alertTitel,alertSubtitle){
   let alert = this.alertCtrl.create({
    title: alertTitel,
    subTitle: alertSubtitle,
    buttons: ['Ok']
  });
  alert.present()
}


   loader:any;
   loadValue="Loading Content..";
   loadingContent(arg){
     this.loader = this.loadingCtrl.create({
       content: this.loadValue,
       spinner: 'dots',
      });
     this.loader.present();
   }
 

loadingContentHide(){
      this.loader.dismiss();
  }


loginPrompt(obj){
  let alert2 = this.alertCtrl.create({
    title: 'McNAUGHTON-MCKAY',
    message: 'Please login to see the details',
    buttons: [
      {
        text: 'CANCEL',
        role: 'cancel',
        handler: () => {
        }
      },
      {
        text: 'LOGIN NOW',
        handler: () => {
          obj.navCtrl.push(LoginPage);
        }
      }
    ]
  });

  alert2.present();
}

  public logoutGlobal(){
    alert("logout"); 
    this.rest.loginState = false;
  }

  public loginGlobal(obj){
    obj.navCtrl.push(LoginPage);
  }


  public loginPop(){
    alert("You are not logged In");
  }
 
 
  generalSearch(val){
        if (!val) {
            this.alert(window.localStorage.getItem("alertTitle"),"Please enter a keyword to search");

        } else {

            var searcharr = [];
            if(window.localStorage.getItem("SearchArray"))
            {
                searcharr = JSON.parse(window.localStorage.getItem("SearchArray"));
            }

            if(searcharr.length <= 20)
            {
                searcharr.push(val);
            }
            else if(searcharr.length > 20){
                searcharr.pop();
            }

            var searchb = this.uniqBy(searcharr, JSON.stringify)
            window.localStorage.setItem("SearchArray", JSON.stringify(searchb));

          //  var value = window.localStorage.getItem("BASE") + '/searchPage.action?keyWord=' + val.value;
            //window.localStorage.setItem("TaxanomyUrl",value);
           // searchhistorypage(value);
            //$.ui.loadAjax(value, false, false, "slide", true);

        }
        
    
}
 uniqBy(a, key) {
  var seen = {};
  return a.filter(function(item) {
                  var k = key(item);
                  return seen.hasOwnProperty(k) ? false : (seen[k] = true);
                  })
}


presentPrompt() {
  let alert = this.alertCtrl.create({
    title: 'McNAUGHTON-MCKAY',
    inputs: [
      {
        name: 'cartName',
        placeholder: 'cart name'
      }
      // ,
      // {
      //   name: 'password',
      //   placeholder: 'Password',
      //   type: 'password'
      // }
    ],
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: data => {
          console.log('Cancel clicked');
        }
      },
      {
        text: 'Save',
        handler: data => {
          if (this.rest.loginState) {

          } else {
            // invalid login
            return false;
          }
        }
      }
    ]
  });
  alert.present();
}
presentConfirm() {
  let alert = this.alertCtrl.create({
    title: 'McNAUGHTON-MCKAY',
    message: 'Do you want to Delete the cart ? ',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
          console.log('Cancel clicked');
        }
      },
      {
        text: 'Delete',
        handler: () => {
          console.log('Buy clicked');
        }
      }
    ]
  });
  alert.present();
}


//search function
searchByEntry(param,countries)
{

  if(typeof param === "undefined" || typeof param === undefined){
    param = "";
   }else{
     param = param;
   }
   
    let val : string 	= param;
    if(val !== "" || val !== undefined ){
   // this.getCountries("test")
  /*  .subscribe(
      countries =>{*/
        countries = countries;
      // DON'T filter the countries IF the supplied input is an empty string
      
      if (val.trim() !== '' )
      {
         countries = countries.filter((item) =>
         {
          // console.log("item"+item);
           return item["capital"].toLowerCase().indexOf(val.toLowerCase()) > -1 || item["region"].toLowerCase().indexOf(val.toLowerCase()) > -1;
         })
      }
      return countries;
    
    //});
  }
}




// speech recog

async hasPermission():Promise<boolean> {
  try {
    const permission = await this.speech.hasPermission();
    console.log(permission);

    return permission;
  } catch(e) {
    console.log(e);
  }
}

async getPermission():Promise<void> {
  try {
    this.speech.requestPermission();
  } catch(e) {
    console.log(e);
  }
}

listen(): Promise<String> {
  console.log('listen action triggered');
  if (this.isListening) {
    this.speech.stopListening();
    this.toggleListenMode();
    return null;
  }

  this.toggleListenMode();
  let _this = this;

  this.speech.startListening()
    .subscribe(matches => {
      _this.zone.run(() => {
        _this.matches = matches;
      })
      return matches;
    }, error => console.error(error));

}

toggleListenMode():void {
  this.isListening = this.isListening ? false : true;
  console.log('listening mode is now : ' + this.isListening);
}



startListen(){
  let _this = this;
  this.speech.startListening()
    .subscribe(
    (matches: Array<string>) => console.log(matches),
    (onerror) => console.log('error:', onerror)
  );
}
stopListen(){
  this.speech.stopListening();
}


//end of speech recog


postRequest(url,data){
  
      return this.http.post(url,data) 
                      .map(this.extractData);
  
  }
  
  getRequest(url){
    return this.http.get(url) 
                .map(this.extractData);
  }
  
  dataselected(data){
   // alert(data);
  }


// searchGeneral(keyCode,item){
 
//   if(keyCode == 13){
//     if(item.length>0 ){
//       this.seachInput = item;
//     }
//     this.loadingContentHide();
//     this.loadingContent('');
//    //this.seachInput = encodeURI(this.seachInput);
//     this.getContent("api/ecomm/v1/catalogs/mine/items?query="+this.seachInput)
//     .subscribe(
//      searchResult =>{
//         if(searchResult.content.length == 1){
//         this.searchResult = searchResult.content[0];      
//         this.setValue(this.searchResult);
//         this.navCtrl.push(ProductdetailPage);
//          }
//          else if(searchResult.content.length > 1){
//          this.searchResult = searchResult.content;      
//          this.setValue(this.searchResult);  
//          this.navCtrl.push(ProductgridPage);
//         }
//         else if(searchResult.content.length == 0){
//           this.loadingContentHide();

//           alert("no item found !..ß");
//         }
//       } ,
//       error =>  {
        
//           console.log(error);
//           //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
//           //this.myprovider.loadingContentHide();
        
//      })

    
//   }
// }

  //push Notification stuff

  async getToken() {  
    let token;

    if (this.platform.is('android')) {
      token = await this.firebaseNative.getToken();
    } 
  
    if (this.platform.is('ios')) {
      token = await this.firebaseNative.getToken();
      await this.firebaseNative.grantPermission();
    } 
    
    return this.saveTokenToFirestore(token)
  }

  // Save the token to firestore
  private saveTokenToFirestore(token) {
    if (!token) return;

  const devicesRef = this.afs.collection('devices')

  const docData = { 
    token,
    userId: 'testUser',
  }

  return devicesRef.doc(token).set(docData)

  }
  setValue(val) {
    this.myValue = val;
 }

getValue() {
    return this.myValue ;
}

  // Listen to incoming FCM messages
  listenToNotifications() {
  return this.firebaseNative.onNotificationOpen()
}
}
