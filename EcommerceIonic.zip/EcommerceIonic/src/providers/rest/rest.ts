import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LoginPage } from '../../pages/login/login';


import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import { App,LoadingController } from "ionic-angular";
import { NavController } from "ionic-angular/index";
import {FormControl, FormGroup, Validators, AbstractControl} from '@angular/forms';

import 'rxjs/add/operator/map'
/*
  Generated class for the RestProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class RestProvider {
  

  private apiUrl = 'https://restcountries.eu/rest/v2/all';
  private navCtrl: NavController;
  constructor(public http: HttpClient, private app:App, public loadingCtrl: LoadingController) {
    this.navCtrl = app.getActiveNav();
  }
  getCountries(): Observable<string[]> {
    return this.http.get(this.apiUrl)
                    .map(this.extractData)
                    .catch(this.handleError);
  }
  
  private extractData(res: Response) {
    let body = res;
    return body || { };
  }
  
  private handleError (error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
      const err = error || '';
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }

 isValidMobile(phonenumber): any {

    let regExp = /^[0-9]{10}$/;

    if (!regExp.test(phonenumber)) {
        return true;
    }
    return false;
}
isValidEmail(email): any {

  let regExp = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  if (!regExp.test(email)) {
      return true;
  }
  return false;
}




// global value decalerd here
  public loginState:boolean = false;
  public myheader :boolean = false;
  public myfilter :boolean = false;
  public cartCount :number=0 ;


  public cartname = "";
  public headerContent = "test";

}






