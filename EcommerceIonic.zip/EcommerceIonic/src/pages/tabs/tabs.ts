import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { AboutPage } from '../about/about';
import { ContactPage } from '../contact/contact';
import { HomePage } from '../home/home';
import { MenuForAppPage } from '../menu-for-app/menu-for-app';
import { LoginPage } from '../login/login';
import { SearchPage } from '../search/search';
import { HelpPage } from '../help/help';
import { CartPage } from '../cart/cart';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = HomePage;
  tab2Root = SearchPage ; 
  tab3Root = CartPage;
  tab4Root = HelpPage;

  constructor(public navCtrl: NavController) {

  }
  navToLogInPage(){
    this.navCtrl.push(LoginPage);
  }
  backToPreviousPage(){
    alert("back");
    this.navCtrl.pop();
    
  }

  
}
