import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../cart/cart';


/**
 * Generated class for the SearchPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-search',
  templateUrl: 'search.html',
})
export class SearchPage {
  searchTerm: string = '';
  items: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public rest: RestProvider) {
  }

  ionViewDidLoad() {
    //this.setFilteredItems();
 }
 ionLoadView(){
 }

 ionViewWillEnter() {
   this.items = JSON.parse(window.localStorage.getItem("SearchArray"));
}


   searchKeyword(keyEvent) {
    
}

navToCartPage(){
  this.navCtrl.push(CartPage);
}

searchKeyword_popup(){
  //this.navCtrl.push(SearchpopupPage);
  this.rest.myheader = true;
}
hidesearchKeyword_popup(){
  //this.navCtrl.push(SearchpopupPage);
  this.rest.myheader = false;
}



}
