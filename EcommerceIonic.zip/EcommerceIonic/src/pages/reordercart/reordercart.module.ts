import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReordercartPage } from './reordercart';

@NgModule({
  declarations: [
    // ReordercartPage,
  ],
  imports: [
    IonicPageModule.forChild(ReordercartPage),
  ],
})
export class ReordercartPageModule {}
