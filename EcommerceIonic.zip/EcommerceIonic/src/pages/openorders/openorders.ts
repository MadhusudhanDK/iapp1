import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { OrderdetailPage } from '../orderdetail/orderdetail';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the OpenordersPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-openorders',
  templateUrl: 'openorders.html',
})
export class OpenordersPage {
  seachInput;
  countries=[];
  errorMessage: string;

  filterCountries:string[];

  constructor(public navCtrl: NavController, public rest: RestProvider, public myprovider:MyprovidersProvider) {
  }

  ionViewDidLoad() {
    this.getCountries();
    
  }
 
  getCountries() {
    this.myprovider.getCountries("test")
       .subscribe(
         countries =>{
         
          this.countries = countries;
          this.filterCountries = countries;
       
         } ,
         error =>  this.errorMessage = <any>error);
  }

  //search item
  filterTechnologies(param : any) : void
   {
    this.countries = this.myprovider.searchByEntry(param,this.filterCountries);
  
   } 
   OrderDetail(){
     this.navCtrl.push(OrderdetailPage);
   }
  

}
