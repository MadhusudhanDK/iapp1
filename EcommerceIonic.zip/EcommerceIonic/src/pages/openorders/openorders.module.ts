import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OpenordersPage } from './openorders';


@NgModule({
  declarations: [
    // OpenordersPage,
  ],
  imports: [
    IonicPageModule.forChild(OpenordersPage),
  ],
})
export class OpenordersPageModule {} 


