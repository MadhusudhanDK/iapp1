import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { CartPage } from '../cart/cart';
import { ProductcategoriesPage } from '../productcategories/productcategories';
/**
 * Generated class for the OrderconfirmationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-orderconfirmation',
  templateUrl: 'orderconfirmation.html',
})
export class OrderconfirmationPage {

  cartData:any;
  errorMessage="";
  seachInput;
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider,public rest: RestProvider) {
  this.myprovider.loadingContent("");

  }

  ionViewDidLoad() {
    this.getCountries();
  }

  getCountries() {
    this.myprovider.getCountries("test")
       .subscribe(
         countries =>{
         
         	this.cartData = countries;
         	this.myprovider.loadingContentHide();
         } ,
         error =>  this.errorMessage = <any>error);
  }

  continueShopping(){
this.navCtrl.push(ProductcategoriesPage);
  }
}
