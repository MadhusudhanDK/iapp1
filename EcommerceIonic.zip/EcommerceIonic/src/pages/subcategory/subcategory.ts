import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ProductgridPage } from '../productgrid/productgrid';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import { TempsubcategoryPage } from '../tempsubcategory/tempsubcategory';
import { CartPage } from '../cart/cart';
import { ProductdetailPage } from '../productdetail/productdetail';

/**
 * Generated class for the SubcategoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-subcategory',
  templateUrl: 'subcategory.html',
})
export class SubcategoryPage {
  catId;
  categories: string[];
  errorMessage: string;
  subcategoryData;
  seachInput;
  searchResult;
  name;
  BASEURL = window.localStorage.getItem("BASEURL");
  CATIMG = window.localStorage.getItem("CATIMG");
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider, public rest: RestProvider) {
    this.subcategoryData = this.navParams.get('subcategoryData'); 
    this.myprovider.loadingContentHide();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SubcategoryPage');
  }


subCategory(id,name){
  this.myprovider.loadingContent('');
  //service
  this.catId = id;
  this.name =name;
  this.myprovider.getContent("api/ecomm/v1/catalogs/mine/categories/"+id+'/children')
           .subscribe(
            categories =>{
             console.log(categories);
             if(categories.content.length > 0){
             // this.subcategoryData = categories.content;
             this.navCtrl.push(TempsubcategoryPage,{subcategoryData:categories.content});
              
             }
             else{
              
              this.searchGeneral(name);
              //this.navCtrl.push(ProductgridPage);
             }
             } ,
             error =>  {
              this.myprovider.loadingContentHide();
              console.log("Token Has been Expired generating a new token");
             if(error == "AccessTokenExpired"){
               this.generateRefreshToken();
             }
             else if(error == "RefreshTokenExpired"){
               this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
             //  this.getCimmToken();
             }
             else{
               this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
               this.myprovider.loadingContentHide();
             }
           })
  }

searchGeneral(item){
    if(item.length>0 ){
      this.seachInput = item;
    }
   //this.seachInput = encodeURI(this.seachInput);
   if(this.seachInput.indexOf('ABB') > -1)
   this.seachInput = this.seachInput.replace("ABB ","");
    this.myprovider.getContent("api/ecomm/v1/catalogs/mine/items?query="+this.seachInput)
    .subscribe(
     searchResult =>{
        if(searchResult.content.length == 1){
        this.searchResult = searchResult.content[0];      
        this.myprovider.setValue(this.searchResult);
        this.myprovider.loadingContentHide();
        this.navCtrl.push(ProductdetailPage);
         }
         else if(searchResult.content.length > 1){
         this.searchResult = searchResult.content;      
         this.myprovider.setValue(this.searchResult);  
         this.navCtrl.push(ProductgridPage);
        }
        else if(searchResult.content.length == 0){
          this.myprovider.loadingContentHide();

          alert("no item found !..ß");
        }
      } ,
      error =>  {
        this.myprovider.loadingContentHide();
        console.log(error);
        if(error == "AccessTokenExpired"){
          this.generateRefreshToken();
        }
        else if(error == "RefreshTokenExpired"){
          this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
        }
        else if(error == "noResource"){
          this.myprovider.loadingContentHide();
          alert("no item found !..ß");
        }
        else{
          console.log(error);
          //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
          //this.myprovider.loadingContentHide();
        }
     })

    
  
}
  generateRefreshToken() {
    this.myprovider.refreshToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
    .subscribe(
      data =>{
        window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
        this.subCategory(this.catId,this.name);
      } ,
      error =>  this.errorMessage = <any>error);
      console.log("refresh token stored : " + this.errorMessage);
  }

  

}
