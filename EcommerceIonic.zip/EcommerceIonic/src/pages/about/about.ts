import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { CartPage } from '../cart/cart';
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';

@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {
  seachInput;
  items: any = new Array(10);
  constructor(public navCtrl: NavController,public myprovider: MyprovidersProvider,public rest: RestProvider) {

  }
  handleOverslide(item){
    console.log(item);
}

}
