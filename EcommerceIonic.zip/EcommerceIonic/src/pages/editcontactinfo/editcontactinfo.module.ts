import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { EditcontactinfoPage } from './editcontactinfo';

@NgModule({
  declarations: [
    // EditcontactinfoPage,
  ],
  imports: [
    IonicPageModule.forChild(EditcontactinfoPage),
  ],
})
export class EditcontactinfoPageModule {}
