import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import {FormBuilder, FormGroup, Validators, AbstractControl} from '@angular/forms';
import { CartPage } from '../cart/cart';
/**
 * Generated class for the EditcontactinfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-editcontactinfo',
  templateUrl: 'editcontactinfo.html',
})
export class EditcontactinfoPage {
  seachInput;
  changePasswordFrom:FormGroup;
  firstName:AbstractControl;
  lastname:AbstractControl;
  billingaddress:AbstractControl;
  city:AbstractControl;
  country:AbstractControl;
  state:AbstractControl;
  phone:AbstractControl;
  email:AbstractControl;
  zipCode:AbstractControl;

  gaming: string;

  countries=[];
  errorMessage: string;

  constructor(public navCtrl: NavController, public formbuilder:FormBuilder,public navParams: NavParams, public rest: RestProvider, public myprovider:MyprovidersProvider) {
      this.changePasswordFrom=formbuilder.group({
        firstName:['',Validators.required],
        lastname:['',Validators.required],
        billingaddress:['',Validators.required],
        city:['',Validators.required],
        country:['',Validators.required],
        state:['',Validators.required],
        phone:['',Validators.required],
        email:['',Validators.required],
        zipCode:['',Validators.required]

    });
    this.firstName=this.changePasswordFrom.controls['firstName'];
    this.lastname=this.changePasswordFrom.controls['lastname'];
    this.billingaddress=this.changePasswordFrom.controls['billingaddress'];
    this.city=this.changePasswordFrom.controls['city'];
    this.country=this.changePasswordFrom.controls['country'];
    this.state=this.changePasswordFrom.controls['state'];
    this.phone=this.changePasswordFrom.controls['phone'];
    this.email=this.changePasswordFrom.controls['email'];
    this.zipCode=this.changePasswordFrom.controls['zipCode'];
  }   


  ionViewDidLoad() {
    this.getCountries();
  }

  getCountries() {
    this.myprovider.getCountries("test")
       .subscribe(
         countries =>{
         
          this.countries = countries;
         
       
         } ,
         error =>  this.errorMessage = <any>error);
  }

}
