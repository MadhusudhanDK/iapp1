import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CartPage } from '../cart/cart';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import { ProductdetailPage } from '../productdetail/productdetail';
import { ProductgridPage } from '../productgrid/productgrid';

/**
 * Generated class for the ManufacturerPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-manufacturer',
  templateUrl: 'manufacturer.html',
})
export class ManufacturerPage {
  brands;
  searchResult;
  seachInput
  errorMessage: string;
  alphabets = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','3M'];

  startsWithN;
  countries;

  constructor(public navCtrl: NavController,public myprovider: MyprovidersProvider, public navParams: NavParams, public rest: RestProvider) {
  }

  ionViewDidLoad() {
    this.getBrands("NoFilter");
  }

  getBrands(alphabet) {

    this.myprovider.getContent("api/ecomm/v1/catalogs/mine/manufacturers")
       .subscribe(
        brands =>{
          alert("d");
          debugger;
          console.log(brands.content);
          this.brands = brands.content;
          if(alphabet!="NoFilter"){
            this.brands = this.brands.filter((brand) => brand.name.startsWith(alphabet));
          }
          this.myprovider.loadingContentHide();
         } ,
         error =>  {
          console.log("Token Has been Expired generating a new token");
         if(error == "AccessTokenExpired"){
           this.generateRefreshToken();
         }
         else if(error == "RefreshTokenExpired"){
           this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
          // this.getCimmToken();
         }
         else{
           this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
           this.myprovider.loadingContentHide();
         }
       })
  }

  generateRefreshToken() {
    this.myprovider.refreshToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
    .subscribe(
      data =>{
        window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
        this.getBrands(this.alphabets);
      } ,
      error =>  this.errorMessage = <any>error);
      console.log("refresh token stored : " + this.errorMessage);
  }

  filterWithAalphabet(alphabet){
   // alert("test"+alphabet);

  }

  
  showAll(item){
    this.searchGeneral(item);
    
      }
    
    
    searchGeneral(item){
     
        this.myprovider.loadingContentHide();
        this.myprovider.loadingContent('');
       //this.seachInput = encodeURI(this.seachInput);
        this.myprovider.getContent("api/ecomm/v1/catalogs/mine/items?filter.manufacturer="+item)
        .subscribe(
         searchResult =>{
            if(searchResult.content.length == 1){
            this.searchResult = searchResult.content[0];      
            this.myprovider.setValue(this.searchResult);
            this.navCtrl.push(ProductdetailPage);
             }
             else if(searchResult.content.length > 1){
             this.searchResult = searchResult.content;      
             this.myprovider.setValue(this.searchResult);  
             this.navCtrl.push(ProductgridPage);
            }
            else if(searchResult.content.length == 0){
              this.myprovider.loadingContentHide();
              alert("no item found !..ß");
            }
          } ,
          error =>  {
            this.myprovider.loadingContentHide();
    
            console.log(error);
            if(error == "AccessTokenExpired"){
              this.generateRefreshToken();
            }
            else if(error == "RefreshTokenExpired"){
              this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
              //this.getCimmToken();
            }
            else if(error == "noResource"){
              alert("no item found !..ß");
            }
            else{
              console.log(error);
              //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
              //this.myprovider.loadingContentHide();
            }
         })
    }

}
