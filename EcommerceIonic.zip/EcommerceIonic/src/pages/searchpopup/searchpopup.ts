import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../cart/cart';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';

/**
 * Generated class for the SearchpopupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-searchpopup',
  templateUrl: 'searchpopup.html',
})
export class SearchpopupPage {
  searchTerm: string = '';
  items: any;
  seachInput;

  constructor(public navCtrl: NavController, public navParams: NavParams, public rest: RestProvider,public myprovider: MyprovidersProvider) {
  }

  ionViewDidLoad() {
    //this.setFilteredItems();
 }
 ionLoadView(){
 }

 ionViewWillEnter() {
   this.items = JSON.parse(window.localStorage.getItem("SearchArray"));
}

}
