import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SearchpopupPage } from './searchpopup';

@NgModule({
  declarations: [
    // SearchpopupPage,
  ],
  imports: [
    IonicPageModule.forChild(SearchpopupPage),
  ],
})
export class SearchpopupPageModule {}
