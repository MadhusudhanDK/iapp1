import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';
import {HomePage} from '../home/home';
import { ProductgridPage } from '../productgrid/productgrid';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { LoadingController } from "ionic-angular";


/**
 * Generated class for the OtherappsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-otherapps',
  templateUrl: 'otherapps.html',
})
export class OtherappsPage {
  countries: string[];
  errorMessage: string;
  loader;
  constructor(public navCtrl: NavController, public navParams: NavParams, public rest: RestProvider, public myprovider:MyprovidersProvider,  public loadingCtrl: LoadingController) {
    this.myprovider.loadingContent('');


}
ionViewDidLoad() {
  this.getCountries();
}



getCountries() {
  this.myprovider.getCountries("test")
     .subscribe(
       countries =>{
       
        this.countries = countries;
        this.myprovider.loadingContentHide();
       } ,
       error =>  this.errorMessage = <any>error);
}
}