import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OtherappsPage } from './otherapps';

@NgModule({
  declarations: [
    // OtherappsPage,
  ],
  imports: [
    IonicPageModule.forChild(OtherappsPage),
  ],
})
export class OtherappsPageModule {}
