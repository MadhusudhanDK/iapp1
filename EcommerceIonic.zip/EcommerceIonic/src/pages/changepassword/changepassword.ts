import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import {FormBuilder, FormGroup, Validators, AbstractControl} from '@angular/forms';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the ChangepasswordPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-changepassword',
  templateUrl: 'changepassword.html',
})
export class ChangepasswordPage {
  changePasswordFrom:FormGroup;
  userName:AbstractControl;
  password:AbstractControl;
  newPassword:AbstractControl;
  seachInput;

  constructor(public navCtrl: NavController, public formbuilder:FormBuilder,public navParams: NavParams, public rest: RestProvider, public myprovider:MyprovidersProvider) {
      this.changePasswordFrom=formbuilder.group({
        userName:['',Validators.required],
        password:['',Validators.required],
        newPassword:['',Validators.required]

    });
    this.userName=this.changePasswordFrom.controls['userName'];
    this.password=this.changePasswordFrom.controls['password'];
    this.newPassword=this.changePasswordFrom.controls['newPassword'];
  }   


  ionViewDidLoad() {
    console.log('ionViewDidLoad ChangepasswordPage');
  }

  changePassword(){
   // alert("test");
  }
  
  resetForm(){
    this.changePasswordFrom.reset()
  }
}
