import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../cart/cart';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';

@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {
  seachInput;
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider, public rest: RestProvider) {

  }

  navToCartPage(){
    this.navCtrl.push(CartPage);
  }

}
