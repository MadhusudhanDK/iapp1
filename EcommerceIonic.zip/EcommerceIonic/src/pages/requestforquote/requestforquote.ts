import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { ProductgridPage } from '../productgrid/productgrid';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { LoadingController } from "ionic-angular";
import {FormBuilder, FormGroup, Validators, AbstractControl} from '@angular/forms';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the RequestforquotePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-requestforquote',
  templateUrl: 'requestforquote.html',
})
export class RequestforquotePage {
   angular: any;
   seachInput;
  formgroup:FormGroup;
  contactname:AbstractControl;
  companyname:AbstractControl;
  contactphone:AbstractControl;
  shipdate:AbstractControl;
  email:AbstractControl;




  constructor(public navCtrl: NavController, public formbuilder:FormBuilder, public rest: RestProvider, public myprovider:MyprovidersProvider,  public loadingCtrl: LoadingController) {
    this.formgroup=formbuilder.group({
      contactname:['',Validators.required],
      companyname:['',Validators.required],
      contactphone:['',Validators.required],
      shipdate:['',Validators.required],
      email:['',Validators.required]

    });
    this.contactname=this.formgroup.controls['contactname'];
    this.companyname=this.formgroup.controls['companyname'];
    this.contactphone=this.formgroup.controls['contactphone'];
    this.shipdate=this.formgroup.controls['shipdate'];
    this.email=this.formgroup.controls['email'];

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }
  result="";
  callSubmitrfq(){
    this.result="";    
    if(this.rest.isValidMobile(this.contactphone.value))
    this.result = this.result + "Enter a valid Phone Number\n";
    if(this.rest.isValidEmail(this.email.value))
    this.result = this.result + "Enter a valid Email Address\n";
    if(this.result == ""){
      alert("form submitted !");
    }

    else{
    alert(this.result);
    }
  }
  addMore(){
    var myEl = document.getElementById( 'rfqitems' );
    var myE2 = document.getElementById( 'elements' ).innerHTML;
   //myEl.innerHTML="Hiiiiiiiiiiiiiiii<br/>"; 
   myEl.innerHTML += myE2;

  }


}
