import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RequestforquotePage } from './requestforquote';

@NgModule({
  declarations: [
    // RequestforquotePage,
  ],
  imports: [
    IonicPageModule.forChild(RequestforquotePage),
  ],
})
export class RequestforquotePageModule {}
