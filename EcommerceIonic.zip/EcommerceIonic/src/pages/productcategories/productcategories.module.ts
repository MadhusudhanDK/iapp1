import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProductcategoriesPage } from './productcategories';

@NgModule({
  declarations: [
    // ProductcategoriesPage,
  ],
  imports: [
    IonicPageModule.forChild(ProductcategoriesPage),
  ],
})
export class ProductcategoriesPageModule {}
