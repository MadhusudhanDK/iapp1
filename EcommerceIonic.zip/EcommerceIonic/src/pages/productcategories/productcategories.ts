import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import {HomePage} from '../home/home';
import { ProductgridPage } from '../productgrid/productgrid';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { LoadingController } from "ionic-angular";
import { CartPage } from '../cart/cart';


@Component({
  selector: 'page-productcategories',
  templateUrl: 'productcategories.html'
})
export class ProductcategoriesPage {

  countries: string[];
  errorMessage: string;
  loader;
  seachInput;
  constructor(public navCtrl: NavController, public rest: RestProvider, public myprovider:MyprovidersProvider,  public loadingCtrl: LoadingController) {
    this.myprovider.loadingContent('');
  }
  
  ionViewDidLoad() {
    this.getCountries();
  }



  getCountries() {
    this.myprovider.getCountries("test")
       .subscribe(
         countries =>{
         
          this.countries = countries;
          this.myprovider.loadingContentHide();
         } ,
         error =>  this.errorMessage = <any>error);
  }

//  Navigation 
productgrid(){
  // this.navCtrl.pop();
  this.navCtrl.push(ProductgridPage);
  
}




}