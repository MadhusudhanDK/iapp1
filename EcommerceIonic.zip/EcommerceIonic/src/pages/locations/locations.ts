import { Component, ViewChild, ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../cart/cart';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';


declare var google;
let myLocationData=[];

myLocationData = [{"latitude":"43.053743","longitude":"-89.304198","branchName":"Madison","locality":"Madison, MI 53716","street":"3050 Progress Rd","phone":"(608) 442-3990","faxNum":"(608) 442-3993","workHour":"","note":"","email":"","distance":0.0,"city":"Madison","state":"MI","zip":"53716","country":"US","tollFreeNum":"(855) 283-7783","customFields":[{"customFieldID":0,"locCustomFieldValueID":0,"userCustomFieldValueID":0,"id":142,"fieldName":"WorkingHours","customFieldvalue":"7 hrs"}]},{"latitude":"43.118242","longitude":"-87.949613","branchName":"Milwaukee","locality":"Milwaukee, WI 53209","street":"2935 W. Silver Spring Drive","phone":"(414) 463-1234","faxNum":"(414) 463-0303","workHour":"","note":"","email":"","distance":0.0,"city":"Milwaukee","state":"WI","zip":"53209","country":"US","tollFreeNum":"(800) 242-0406","customFields":[{"customFieldID":0,"locCustomFieldValueID":0,"userCustomFieldValueID":0,"id":143,"fieldName":"WorkingHours","customFieldvalue":"7 hrs"}]},{"latitude":"42.714079","longitude":"-87.911698","branchName":"Racine","locality":"Sturtevant, WI 53177","street":"1661 Renaissance Blvd","phone":"(262) 886-5055","faxNum":"(262) 886-5414","workHour":"","note":"","email":"","distance":0.0,"city":"Sturtevant","state":"WI","zip":"53177","country":"US","tollFreeNum":"(800) 924-5002","customFields":[{"customFieldID":0,"locCustomFieldValueID":0,"userCustomFieldValueID":0,"id":144,"fieldName":"WorkingHours","customFieldvalue":"7 hrs"}]},{"latitude":"43.702051","longitude":"-87.75915","branchName":"Sheboygan","locality":"Sheboygan, WI 53081","street":"4606 S Taylor Dr","phone":"(920) 803-0771","faxNum":"(920) 803-0773","workHour":"","note":"","email":"","distance":0.0,"city":"Sheboygan","state":"WI","zip":"53081","country":"US","tollFreeNum":"(800) 291-4448","customFields":[{"customFieldID":0,"locCustomFieldValueID":0,"userCustomFieldValueID":0,"id":145,"fieldName":"WorkingHours","customFieldvalue":"7 hrs"}]},{"latitude":"43.043815","longitude":"-88.182505","branchName":"Waukesha","locality":"Waukesha, WI 53186","street":"21795 Doral Rd","phone":"(262) 798-9600","faxNum":"(262) 798-9602","workHour":"","note":"","email":"","distance":0.0,"city":"Waukesha","state":"WI","zip":"53186","country":"US","tollFreeNum":"","customFields":[{"customFieldID":0,"locCustomFieldValueID":0,"userCustomFieldValueID":0,"id":146,"fieldName":"WorkingHours","customFieldvalue":"7 hrs"}]},{"latitude":"44.203456","longitude":"-88.498033","branchName":"Neenah","locality":"Neenah, MN 54956","street":"785 County Rd. CB  Suite 200","phone":"(920) 886-3222","faxNum":"(920) 886-8718","workHour":"7:30 AM - 4:30 PM","note":"","email":"","distance":0.0,"city":"Neenah","state":"MN","zip":"54956","country":"US","tollFreeNum":"(888) 203-3445","customFields":[{"customFieldID":0,"locCustomFieldValueID":0,"userCustomFieldValueID":0,"id":147,"fieldName":"WorkingHours","customFieldvalue":"7 hrs"}]},{"latitude":"44.988072","longitude":"-93.452501","branchName":"Plymouth","locality":"Plymouth, ND 55441","street":"865 Xenium Lane N","phone":"(763) 971-2910","faxNum":"(763) 971-2920","workHour":"","note":"","email":"","distance":0.0,"city":"Plymouth","state":"ND","zip":"55441","country":"US","tollFreeNum":"(800) 969-2792","customFields":[{"customFieldID":0,"locCustomFieldValueID":0,"userCustomFieldValueID":0,"id":148,"fieldName":"WorkingHours","customFieldvalue":"7 hrs"}]},{"latitude":"46.890716","longitude":"-96.883898","branchName":"Fargo","locality":"West Fargo, ND 58078","street":"855 12th Ave NE","phone":"(701) 353-4822","faxNum":"(701) 353-7770","workHour":"","note":"","email":"","distance":0.0,"city":"West Fargo","state":"ND","zip":"58078","country":"US","tollFreeNum":"(855) 283-7783","customFields":[{"customFieldID":0,"locCustomFieldValueID":0,"userCustomFieldValueID":0,"id":149,"fieldName":"WorkingHours","customFieldvalue":"7 hrs"}]}];

@IonicPage()
@Component({
  selector: 'page-locations',
  templateUrl: 'locations.html',
})

export class LocationsPage {

  @ViewChild('map') mapElement: ElementRef;
  map: any;
  marker :any;
  seachInput;


  start = 'chicago, il';
  end = 'chicago, il';
  directionsService = new google.maps.DirectionsService;
  directionsDisplay = new google.maps.DirectionsRenderer;
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider, public rest: RestProvider) {
  }

  ionViewDidLoad() {
    this.initMap();
  }
  initMap() {

    this.map = new google.maps.Map(this.mapElement.nativeElement, {
      zoom: 4,
      center: {lat: +myLocationData[0].latitude, lng: +myLocationData[0].longitude}
    });


    this.directionsDisplay.setMap(this.map);
    for (let location in myLocationData) {
      this.marker = new google.maps.Marker({
        position: {lat:Number(myLocationData[location].latitude), lng: Number(myLocationData[location].longitude)},
        map: this.map,
        title: 'Hello World!'
      });
    }

  }

  calculateAndDisplayRoute() {
    this.directionsService.route({
      origin: this.start,
      destination: this.end,
      travelMode: 'DRIVING'
    }, (response, status) => {
      if (status === 'OK') {
        this.directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }

}
