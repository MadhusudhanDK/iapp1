import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SavedcartdetailsPage } from './savedcartdetails';

@NgModule({
  declarations: [
    // SavedcartdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(SavedcartdetailsPage),
  ],
})
export class SavedcartdetailsPageModule {}
