import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the SavedcartdetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-savedcartdetails',
  templateUrl: 'savedcartdetails.html',
})
export class SavedcartdetailsPage {
  cartData:any;
  errorMessage="";
  seachInput;
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider,public rest: RestProvider) {
   // this.myprovider.loadingContent('');
  }

  ionViewDidLoad() {
    this.getCountries();
  }

  getCountries() {
    this.myprovider.getCountries("test")
       .subscribe(
         countries =>{
         
         	this.cartData = countries;
         	this.myprovider.loadingContentHide();
         } ,
         error =>  this.errorMessage = <any>error);
  }
editCart(){
  this.myprovider.presentPrompt();
}
deleteCart(){
  this.myprovider.presentConfirm();
}


}
