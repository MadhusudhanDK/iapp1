import { Component } from '@angular/core';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { ProductdetailPage } from '../../pages/productdetail/productdetail';
import { LoadingController } from "ionic-angular";
import { FilterPage } from '../filter/filter';
import { CartPage } from '../cart/cart';
import { ProductgroupPage } from '../productgroup/productgroup';
import { ProductcategoriesPage } from '../productcategories/productcategories';

/**
 * Generated class for the ProductgridPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-productgrid',
  templateUrl: 'productgrid.html',
})
export class ProductgridPage {
  seachInput;
  productGridData;
  searchResult;
  Data;
  qtyTextBox=1;
  countries: string[];
  errorMessage: string;
  isGrid=false;
  c;
  product={name:"Select",id:0};
  productdata=[{name:"Andy",id:1},{name:"Sandy",id:2},{name:"Candy",id:3}];
  constructor(public navCtrl: NavController, public toastCtrl: ToastController, public rest: RestProvider, public myprovider:MyprovidersProvider) {
    this.productGridData = this.myprovider.getValue(); 
    this.myprovider.loadingContentHide();
  }

  ionViewDidLoad() {
   // this.getCountries();
  }

  decCount(){
      if(this.qtyTextBox != undefined  && this.qtyTextBox > 0){
        this.qtyTextBox -= 1;
      }
  
  } 
  incCount(){
    if(this.qtyTextBox != undefined  ){
      this.qtyTextBox += 1;
    }
  }
  getCountries() {
    this.myprovider.getCountries("test")
       .subscribe(
         countries => this.countries = countries,
         error =>  this.errorMessage = <any>error);
  }
  productDetail(partNumber){
    console.log(partNumber);
   this.searchGeneral(partNumber);
  }

  showGridList(){
    if(this.isGrid){
      this.isGrid=false;
    }else{
      this.isGrid=true;
    }
  }

searchKeyword_popup(){
  //this.navCtrl.push(SearchpopupPage);
  this.rest.myheader = true;
}
hidesearchKeyword_popup(){
  //this.navCtrl.push(SearchpopupPage);
  this.rest.myheader = false;
}
showFilters(){
  this.navCtrl.push(FilterPage);
}
  AddToCart(c){
    this.c =c;
    this.myprovider.loadingContent('');
    this.Data ={
      "quantity":4,
      "brand" :c.brand,
      "manufacturer":c.manufacturer,
      "price": c.pricingWarehouse.customerPrice,
      "shortDesc": c.description,
      "id":c.id,
      "userId":7179,
      "itemId":c.manfId
       };
       this.Data ={
        "quantity":1,
        "brand" :"CREATECART61",
        "manufacturer":"AAA",
        "price": 20.0,
        "shortDesc": "Short Desc Brand Test",
        "id":"8901",
        "userId":7179,
        "itemId":"790286"
         }
    //   alert(c.brand+"+"+c.manufacturer+"+"+c.pricingWarehouse.customerPrice+"+"+c.description+"+"+c.id+"+"+c.manfId);
    this.myprovider.postContent("api/ecomm/v1/users/me/carts",this.Data)
    .subscribe(
      cartItems =>{
        let toast = this.toastCtrl.create({
          message: 'Added to Cart',
          duration: 3000,
          position: 'bottom'
        });
        toast.present();
        this.rest.cartCount = cartItems.content.totalCartItems;
        this.myprovider.loadingContentHide();
      } ,
      error =>  {
        console.log("Token Has been Expired generating a new token");
       if(error == "AccessTokenExpired"){
         this.generateRefreshToken();
       }
       else if(error == "RefreshTokenExpired"){
         this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
       }
       else{
         this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
        //  this.myprovider.alert(window.localStorage.getItem("alertTitle"),error.error.errors[0].errorMessage);
         this.myprovider.loadingContentHide();
       }
     })
  }

  AddToProductGroup(){
    //this.navCtrl.push(ProductgroupPage);
    this.navCtrl.push(ProductgroupPage,{"type":"addItem"});
  }

  generateRefreshToken() {
    this.myprovider.refreshToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
    .subscribe(
      data =>{
        window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
        this.AddToCart(this.c);
      } ,
      error =>  this.errorMessage = <any>error);
      console.log("refresh token stored : " + this.errorMessage);
  }

  navToCartPage(){
    this.navCtrl.push(CartPage);
  }
  searchKeyword(){
    this.myprovider.generalSearch(this.seachInput);
  }

  searchGeneral(item){
      if(item.length>0 ){
        this.seachInput = item;
      }
      this.myprovider.loadingContent('');
     //this.seachInput = encodeURI(this.seachInput);
     if(this.seachInput.indexOf('ABB') > -1)
     this.seachInput = this.seachInput.replace("ABB ","");
      this.myprovider.getContent("api/ecomm/v1/catalogs/mine/items?query="+this.seachInput)
      .subscribe(
       searchResult =>{
          if(searchResult.content.length == 1){
          this.searchResult = searchResult.content[0];      
          this.myprovider.setValue(this.searchResult);
          this.navCtrl.push(ProductdetailPage);
           }
           else if(searchResult.content.length > 1){
           this.searchResult = searchResult.content;      
           this.myprovider.setValue(this.searchResult);  
           this.navCtrl.push(ProductgridPage);
          }
          else if(searchResult.content.length == 0){
            this.myprovider.loadingContentHide();

            alert("no item found !..ß");
          }
        } ,
        error =>  {
          console.log(error);
          if(error == "AccessTokenExpired"){
            this.generateRefreshToken();
          }
          else if(error == "RefreshTokenExpired"){
            this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
            //this.getCimmToken();
          }
          else if(error == "noResource"){
            this.myprovider.loadingContentHide();
            alert("no item found !..ß");
          }
          else{
            console.log(error);
            //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
            //this.myprovider.loadingContentHide();
          }
       })
  
      
    
  }

}
