import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProductgridPage } from './productgrid';

@NgModule({
  declarations: [
    // ProductgridPage,
  ],
  imports: [
    IonicPageModule.forChild(ProductgridPage),
  ],
})
export class ProductgridPageModule {}
