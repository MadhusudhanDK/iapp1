import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, ToastController } from 'ionic-angular';
import { ProductgroupdetailsPage } from '../productgroupdetails/productgroupdetails';
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the ProductgroupPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-productgroup',
  templateUrl: 'productgroup.html',
})
export class ProductgroupPage {
  type;
  countries: string[];
  errorMessage: string;
  seachInput;
  groupNames: string[];
  htmlErrorContent = "";
  dummyData= {
      "itemId":758867,
      "quantity":3,
      "price":"2",
      "manufacturer":"3M",
      "shortDescription":"3M ManuFacture"
     };
  constructor(public navCtrl: NavController,public alertCtrl : AlertController, public navParams: NavParams, public rest: RestProvider, public myprovider: MyprovidersProvider,private toastCtrl: ToastController) {
    this.type = this.navParams.get('type');
  }

  ionViewDidLoad() {
    this.getGroupNames();
  }
  getGroupNames() {
    this.myprovider.getContent("api/ecomm/v1/users/me/productgroups")
    .subscribe(
      groupNames =>{
      //console.log(categories);
      this.groupNames = groupNames.content;
       this.myprovider.loadingContentHide();
      } ,
      error =>  {
       // console.log("Token Has been Expired generating a new token");
       if(error == "AccessTokenExpired"){
        // this.generateRefreshToken();
       }
       else if(error == "RefreshTokenExpired"){
         this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
         //this.getCimmToken();
       }
       else{
         //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
         //this.myprovider.loadingContentHide();
       }
     })
}
    
    groupSeclect(id,name){
      if(this.type == "addItem")
      this.addToGroup(id,name);
      else
      this.navCtrl.push(ProductgroupdetailsPage,{itemid:id});
  }


  addToGroup(id,name){
    this.myprovider.loadingContent('');
    this.myprovider.postContent("api/ecomm/v1/users/me/productgroups/"+id+"/productgroupitems",this.dummyData)
    .subscribe(
      cartItems =>{
        let toast = this.toastCtrl.create({
          message: 'Added to Group '+name,
          duration: 3000,
          position: 'bottom'
        });
        toast.present();
        this.rest.cartCount = cartItems.content.totalCartItems;
        this.myprovider.loadingContentHide();
      } ,
      error =>  {
        console.log("Token Has been Expired generating a new token");
       if(error == "AccessTokenExpired"){
         this.generateRefreshToken();
       }
       else if(error == "RefreshTokenExpired"){
         this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
       }
       else{
         this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
        //  this.myprovider.alert(window.localStorage.getItem("alertTitle"),error.error.errors[0].errorMessage);
         this.myprovider.loadingContentHide();
       }
     })
  }


  getCimmToken() {
    this.myprovider.getAccessToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
    .subscribe(
      data =>{
      window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
      window.localStorage.setItem("REFRESH_TOKEN", data.refresh_token);  
      //console.log("Acceess token stored : " + window.localStorage.getItem("ACCESS_TOKEN"));
     // console.log("refresh token stored : " + window.localStorage.getItem("REFRESH_TOKEN"));
      this.getGroupNames();
      } ,
      error =>  {
        // console.log("Token Has been Expired generating a new token");
        if(error == "AccessTokenExpired"){
          this.generateRefreshToken();
        }
        else if(error == "RefreshTokenExpired"){
          this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
          this.getCimmToken();
        }
        else{
          if(error.indexOf('html') >= 0){
           this.htmlErrorContent = error.split("<body>")[1];
           this.htmlErrorContent = this.htmlErrorContent.replace('<img src=','<img src="'+window.localStorage.getItem("APIURL")+'maintenance/logo.png');
           this.myprovider.loadingContentHide();
          }
          else{
          this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
          this.myprovider.loadingContentHide();
          }
        }
      });
      //console.log("refresh token stored : " + this.errorMessage);
  }
  generateRefreshToken() {
    this.myprovider.refreshToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
    .subscribe(
      data =>{
        window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
        this.getGroupNames();
      } ,
      error =>  this.errorMessage = <any>error);
      //console.log("refresh token stored : " + this.errorMessage);
  }
  
}
