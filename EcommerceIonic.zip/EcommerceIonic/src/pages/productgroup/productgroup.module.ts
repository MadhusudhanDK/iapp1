import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProductgroupPage } from './productgroup';

@NgModule({
  declarations: [
    // ProductgroupPage,
  ],
  imports: [
    IonicPageModule.forChild(ProductgroupPage),
  ],
})
export class ProductgroupPageModule {}
