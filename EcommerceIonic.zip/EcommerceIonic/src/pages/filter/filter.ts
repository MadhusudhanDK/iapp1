import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../cart/cart';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';

/**
 * Generated class for the FilterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

 

@IonicPage()
@Component({
  selector: 'page-filter',
  templateUrl: 'filter.html',
})
export class FilterPage {
  seachInput;
  filterChecked;
  filterCheckedData=[];
  showHideContentName="";
  filterData=[
  {name:"Brands",id:1,data:[
  {name:"Bathroom Vanities Without Tops",id:1},
  {name:"Vanities Without Tops",id:2},
  {name:"Without Tops",id:3}
  ]},
  {name:"ManuFactures",id:2,data:[
  {name:"Foremost Group",id:1},
  {name:"Sunco",id:2},
  {name:"Lentes",id:3}
  ]},
  // {name:"Material",id:3,data:[
  // {name:"Material-data 1",id:1},
  // {name:"Material-data 2",id:2},
  // {name:"Material-data 3",id:3},
  // {name:"Material-data 4",id:4}
  // ]},
  // {name:"Color",id:4,data:[
  // {name:"Color-data 1",id:1},
  // {name:"Color-data 2",id:2},
  // {name:"Color-data 3",id:3},
  // {name:"Color-data 4",id:4}
  // ]}
  ]

  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider, public rest : RestProvider ) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad FilterPage');
  }

  showHideContent(data){
    this.showHideContentName=data.name;
  }
chkbChange(cc){
    if(cc.checked){
        this.filterCheckedData.push(cc);
    }else{
      for(let p=0;p<this.filterCheckedData.length;p++){
        if(this.filterCheckedData[p].id==cc.id){
          this.filterCheckedData.splice(p,1);
        }
      }
    }
  }

  btnSearchClick(){
    if(this.filterCheckedData.length>0){
      alert("Searching For"+ JSON.stringify(this.filterCheckedData));
    }
  }



  filter_popup(){
    //this.navCtrl.push(SearchpopupPage);
    this.rest.myfilter = true;
  }
  hidefilter_popup(){
    //this.navCtrl.push(SearchpopupPage);
  
    this.rest.myfilter = false;
  }

}
