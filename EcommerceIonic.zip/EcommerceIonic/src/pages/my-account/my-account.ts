import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {HomePage} from '../home/home';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import { ProductcategoriesPage } from '../productcategories/productcategories';

import { SavedcartPage } from '../savedcart/savedcart';
import { ProductgroupPage } from '../productgroup/productgroup';
import { OpenordersPage } from '../openorders/openorders';
import { ChangeshipaddressPage } from '../changeshipaddress/changeshipaddress';
import { ChangepasswordPage } from '../changepassword/changepassword';
import { AccountdashboardPage } from '../accountdashboard/accountdashboard';
import { RequestforquotePage } from '../requestforquote/requestforquote';
import { OrderhistoryPage } from '../orderhistory/orderhistory';
import { EditcontactinfoPage } from '../editcontactinfo/editcontactinfo';
import { CartPage } from '../cart/cart';
/**
 * Generated class for the MyAccountPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-my-account',
  templateUrl: 'my-account.html',
})
export class MyAccountPage {
  countries: string[];
  errorMessage: string;
  seachInput;
  constructor(public navCtrl: NavController, public navParams: NavParams, public rest: RestProvider, public myprovider:MyprovidersProvider) {
  }

  ionViewDidLoad() {
    // this.getCountries();
  }
  getCountries() {
    this.myprovider.getCountries('myaccount')
       .subscribe(
         countries => this.countries = countries,
         error =>  this.errorMessage = <any>error);
  }

//  Navigation 
productgrid(){
  // this.navCtrl.pop();
  this.navCtrl.push(ProductcategoriesPage);
  setTimeout(() => {
    this.myprovider.loadingContentHide();
  }, 2000);
  
}

savedCart(){
  if(this.rest.loginState)
  this.navCtrl.push(SavedcartPage);
  else
  this.myprovider.loginPrompt(this);

}
savedGroup(){
  if(this.rest.loginState)
  this.navCtrl.push(ProductgroupPage);
  else
  this.myprovider.loginPrompt(this);

}
openOrders(){
  if(this.rest.loginState)
  this.navCtrl.push(OpenordersPage);
  else
  this.myprovider.loginPrompt(this);

}
changeShipaddress(){
  this.navCtrl.push(ChangeshipaddressPage);
}
changePassword(){
  this.navCtrl.push(ChangepasswordPage);
}
accountDashboard(){
  this.navCtrl.push(AccountdashboardPage);
}
rfq(){
  this.navCtrl.push(RequestforquotePage);
}
orderHistory(){
  this.navCtrl.push(OrderhistoryPage);
}
editcontactinfo(){
  this.navCtrl.push(EditcontactinfoPage);
}



}
