import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MenuForAppPage } from './menu-for-app';

@NgModule({
  declarations: [
    // MenuForAppPage,
  ],
  imports: [
    IonicPageModule.forChild(MenuForAppPage),
  ],
})
export class MenuForAppPageModule {}
