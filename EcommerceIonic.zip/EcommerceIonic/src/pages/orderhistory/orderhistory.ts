import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';

import {FormBuilder, FormGroup, Validators, AbstractControl} from '@angular/forms';
import { CartPage } from '../cart/cart';
/**
 * Generated class for the OrderhistoryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-orderhistory',
  templateUrl: 'orderhistory.html',
})
export class OrderhistoryPage {
  seachInput;
  countries=[];
  errorMessage: string;
  filterCountries:string[];

  fromDate: string;
  toDate: string
  maxDate : string;


formgroup:FormGroup;
  userName:AbstractControl;
  password:AbstractControl;
  constructor(public navCtrl: NavController,public navParams: NavParams,public formbuilder:FormBuilder, public rest: RestProvider, public myprovider:MyprovidersProvider) {
    this.fromDate = new Date().toISOString(); 
    this.toDate = new Date().toISOString(); 
  
    this.formgroup=formbuilder.group({
    

    });
  
  }

  ionViewDidLoad() {
    this.getCountries();
    
  }
 
  getCountries() {
    this.myprovider.getCountries("test")
       .subscribe(
         countries =>{
         
          this.countries = countries;
          this.filterCountries = countries;
       
         } ,
         error =>  this.errorMessage = <any>error);
  }

  //search item
  filterTechnologies(param : any) : void
   {
    this.countries = this.myprovider.searchByEntry(param,this.filterCountries);
  
   } 
   navToCartPage(){
    this.navCtrl.push(CartPage);
  }
}
