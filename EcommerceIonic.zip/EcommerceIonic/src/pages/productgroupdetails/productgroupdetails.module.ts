import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProductgroupdetailsPage } from './productgroupdetails';

@NgModule({
  declarations: [
    // ProductgroupdetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(ProductgroupdetailsPage),
  ],
})
export class ProductgroupdetailsPageModule {}
