import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the ProductgroupdetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-productgroupdetails',
  templateUrl: 'productgroupdetails.html',
})
export class ProductgroupdetailsPage {
  cartData:any;
  errorMessage="";
  seachInput;
  groupItems;
  id;
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider,public rest: RestProvider) {
    this.myprovider.loadingContent('');
    this.id = this.navParams.get('itemid'); 
  }
  ionViewDidLoad() {
    this.getGroupItems();
  }

  getGroupItems() {
    this.myprovider.getContent("api/ecomm/v1/users/me/productgroups/"+this.id+"/productgroupitems")
    .subscribe(
     groupItems =>{
      //console.log(categories);
       this.groupItems = groupItems.content;
       this.myprovider.loadingContentHide();
      } ,
      error =>  {
       // console.log("Token Has been Expired generating a new token");
       if(error == "AccessTokenExpired"){
       //  this.generateRefreshToken();
       }
       else if(error == "RefreshTokenExpired"){
         this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
       //  this.getCimmToken();
       }
       else{
         //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
         //this.myprovider.loadingContentHide();
       }
     })
}
editCart(){
  this.myprovider.presentPrompt();
}
deleteCart(){
  this.myprovider.presentConfirm();
}
}
