import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';
import { ProductgridPage } from '../productgrid/productgrid';
import { RestProvider } from '../../providers/rest/rest';
import { ImageViewerController } from 'ionic-img-viewer';
import { CartPage } from '../cart/cart';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import * as  HomePage  from '../home/home';
import { ProductgroupPage } from '../productgroup/productgroup';

/**
 * Generated class for the ProductdetailPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-productdetail',
  templateUrl: 'productdetail.html',
})
export class ProductdetailPage {
  slideData = [{ image: "assets/imgs/grey.jpg" },{ image: "assets/imgs/grey.jpg" },{ image: "assets/imgs/grey.jpg" }, {image: "assets/imgs/grey.jpg" }];
  seachInput;
  baseurl;
  filterChecked;
  productDetailData;
  filterCheckedData=[];
  showHideContentName="";
  showHideContentTemp="";
  dummyData= {
    "quantity":1,
    "brand" :"CREATECART61",
    "manufacturer":"AAA",
    "price": 20.0,
    "shortDesc": "Short Desc Brand Test",
    "id":"8901",
    "userId":7179,
    "itemId":"790286"
     }
  filterData=[
  {name:"DESCRIPTION",id:1,data:[
  {name:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at porttitor sem.  Aliquam erat volutpat. Donec placerat nisl magna, et faucibus arcu condimentum sed.",id:1}
  ]},
  {name:"SPECIFICATIONS",id:2,data:[
  {name:"Specifications: 3/8-20",id:1},
  {name:"Suitable For Use With : 870 Expander Assembly",id:2}
  ]},
  {name:"DOCUMENTS",id:4,data:[
  {name:"Doc-1",id:1},
  {name:"Doc-2",id:2}
  ]}
  ]
  constructor(public navCtrl: NavController, public navParams: NavParams,private toastCtrl: ToastController, public rest: RestProvider,public _imageViewerCtrl: ImageViewerController,public myprovider: MyprovidersProvider) {
    this.productDetailData = this.myprovider.getValue(); 
    this.myprovider.loadingContentHide();
  }

  ionViewDidLoad() {
    this.getCountries();
    this.baseurl=window.localStorage.getItem("BASEURL");
  }
  countries: string[];
  errorMessage: string;
 
  appendsearchResultData(){
  }
  getCountries() {
    console.log("tedt");
    this.rest.getCountries()
       .subscribe(
         countries => this.countries = countries,
         error =>  this.errorMessage = <any>error);
  }


  AddToCart(){
    this.myprovider.loadingContent('');
    this.myprovider.postContent("api/ecomm/v1/users/me/carts",this.dummyData)
    .subscribe(
      cartItems =>{
        let toast = this.toastCtrl.create({
          message: 'Added to Cart',
          duration: 3000,
          position: 'bottom'
        });
        toast.present();
        this.rest.cartCount = cartItems.content.totalCartItems;
        this.myprovider.loadingContentHide();
      } ,
      error =>  {
        console.log("Token Has been Expired generating a new token");
       if(error == "AccessTokenExpired"){
        // this.generateRefreshToken();
       }
       else if(error == "RefreshTokenExpired"){
         this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
       }
       else{
         this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
        //  this.myprovider.alert(window.localStorage.getItem("alertTitle"),error.error.errors[0].errorMessage);
         this.myprovider.loadingContentHide();
       }
     })
  }

  searchKeyword_popup(){
    //this.navCtrl.push(SearchpopupPage);
    this.rest.myheader = true;
  }
  hidesearchKeyword_popup(){
    //this.navCtrl.push(SearchpopupPage);
    
    this.rest.myheader = false;
  }

  showHideContent(data){
    if(data.name == this.showHideContentTemp){
      this.showHideContentName="";
      this.showHideContentTemp="";
    }
    else{
      this.showHideContentName=data.name;
      this.showHideContentTemp=data.name;
    }
  }

  presentImage(myImage) {
    const imageViewer = this._imageViewerCtrl.create(myImage);
    imageViewer.present();

    setTimeout(() => imageViewer.dismiss(), 30000);
    imageViewer.onDidDismiss(() => alert('Viewer dismissed'));
  }
  AddToProductGroup(){

    //this.navCtrl.push(ProductgroupPage);
    this.navCtrl.push(ProductgroupPage,{"type":"addItem"});

  }


}
