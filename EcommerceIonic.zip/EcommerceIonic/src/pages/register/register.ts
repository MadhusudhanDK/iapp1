import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  seachInput;
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider  ,public rest: RestProvider) {
    
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad RegisterPage');
  }


}
