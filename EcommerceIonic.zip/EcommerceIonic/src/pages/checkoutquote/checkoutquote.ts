import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { ConfirmorderPage } from '../confirmorder/confirmorder';
import { CartPage } from '../cart/cart';
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';

/**
 * Generated class for the CheckoutquotePage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-checkoutquote',
  templateUrl: 'checkoutquote.html',
})
export class CheckoutquotePage {
  seachInput;
  //this is used for Next and  Previous functionality, values used is based on segment in html design, if value is changed ther chenge here,
	segmentList=["billingaddress","shippingaddress","ordernote"];
	segmentSelected: string = "billingaddress";
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider,public rest: RestProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CheckoutPage');
  }

  btnNextClick(){
  	let index=this.segmentList.indexOf(this.segmentSelected);
  	this.segmentSelected=this.segmentList[index+1];

  }

  btnPreviousClick(){
  	let index=this.segmentList.indexOf(this.segmentSelected);
  	this.segmentSelected=this.segmentList[index-1];
  }

 
  confirmOrder(){
    this.navCtrl.push(ConfirmorderPage);
  }

}
