import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CheckoutquotePage } from './checkoutquote';

@NgModule({
  declarations: [
    // CheckoutquotePage,
  ],
  imports: [
    IonicPageModule.forChild(CheckoutquotePage),
  ],
})
export class CheckoutquotePageModule {}
