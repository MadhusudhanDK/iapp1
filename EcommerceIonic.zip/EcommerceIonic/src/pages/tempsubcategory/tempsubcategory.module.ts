import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TempsubcategoryPage } from './tempsubcategory';

@NgModule({
  declarations: [
    // TempsubcategoryPage,
  ],
  imports: [
    IonicPageModule.forChild(TempsubcategoryPage),
  ],
})
export class TempsubcategoryPageModule {}
