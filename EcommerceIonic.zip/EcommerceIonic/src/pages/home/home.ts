import { Component } from '@angular/core';
import { NavController,ActionSheetController,PopoverController,ViewController ,NavParams } from 'ionic-angular';
import { ProductcategoriesPage } from '../productcategories/productcategories';
import { LoginPage } from '../login/login';
import { LoadingController } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { DeprecatedDatePipe } from '@angular/common';
import { MyAccountPage } from '../my-account/my-account';
import { PhotoenqueryPage } from '../photoenquery/photoenquery';
import { SavedcartPage } from '../savedcart/savedcart';
import { ProductgroupPage } from '../productgroup/productgroup';
import { OtherappsPage } from '../otherapps/otherapps';
import { ProductgridPage } from '../productgrid/productgrid';
import { MyApp } from '../../app/app.component';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { SearchpopupPage } from '../searchpopup/searchpopup';
import { CartPage } from '../cart/cart';
import { SubcategoryPage } from '../subcategory/subcategory';
import { ProductdetailPage } from '../productdetail/productdetail';
import { BarcodeScanner ,BarcodeScannerOptions } from '@ionic-native/barcode-scanner';

// import {UtilsService} from '../../providers/rest/rest';
//Pop over content and controller start

@Component({
  template: `
  
  	<h4 class="heading">Results</h4>
    <ion-list no-lines>
    	<ion-item *ngFor="let item of data" tappable (click)="itemSelected(item)">
		  {{ item.description }}
		  
	  	</ion-item>  
	</ion-list>
  `
})
export  class PopoverPage {
  seachInput;
  searchResult;
	data;
  constructor(public navCtrl_:NavController, public viewCtrl: ViewController,public navParams: NavParams,public myprovider: MyprovidersProvider) {
  	this.data=this.navParams.data;
  }

  close() {
    this.viewCtrl.dismiss();
  }

  itemSelected(item){
    this.myprovider.dataselected(item);  	
    this.close();
    this.searchGeneral(13,item);
  }
  searchGeneral(keyCode,item){
 
    if(keyCode == 13){
      if(item.length>0 ){
        this.seachInput = item;
      }
      this.myprovider.loadingContentHide();
      this.myprovider.loadingContent('');
     //this.seachInput = encodeURI(this.seachInput);
      this.myprovider.getContent("api/ecomm/v1/catalogs/mine/items?query="+this.seachInput)
      .subscribe(
       searchResult =>{
          if(searchResult.content.length == 1){
          this.searchResult = searchResult.content[0];      
          this.myprovider.setValue(this.searchResult);
          this.navCtrl_.push(ProductdetailPage);
           }
           else if(searchResult.content.length > 1){
           this.searchResult = searchResult.content;      
           this.myprovider.setValue(this.searchResult);  
           this.navCtrl_.push(ProductgridPage);
          }
          else if(searchResult.content.length == 0){
            this.myprovider.loadingContentHide();
  
            alert("no item found !..ß");
          }
        } ,
        error =>  {
          
            console.log(error);
            //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
            //this.myprovider.loadingContentHide();
          
       })
  
      
    }
  }
}

//Pop over content and controller end
//---------------------------------------------------

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  title = "r";
  users: any;
  seachInput;
  countries: string[];
  categories: string[];
  errorMessage: string;
  BASEURL ="";
  CATIMG = "";
  slideData;
  htmlErrorContent = "";
  value;
  searchResult;
  text: string;
  scanData : {};
  encodedData : {} ;
  options :BarcodeScannerOptions;
  constructor(private barcodeScanner: BarcodeScanner, public navCtrl: NavController, public loadingCtrl: LoadingController, public rest: RestProvider,public myprovider: MyprovidersProvider,private camera: Camera,public actionSheetCtrl:ActionSheetController,public popoverCtrl: PopoverController) {
    this.myprovider.loadingContent('');
    window.localStorage.setItem("APIURL", "https://cimmesbstage.cimm2.com/");
    window.localStorage.setItem("BASEURL", "https://www.gerrie.com/");
    window.localStorage.setItem("AUTHUSER", "mobiletest@gerrie.com");
    window.localStorage.setItem("AUTHPWD", "password");
    window.localStorage.setItem("CATIMG", "ASSETS/IMAGES/CATEGORIES/LIST_DISPLAY/");
    window.localStorage.setItem("LISTIMG", "ASSETS/IMAGES/ITEMS/DETAIL_PAGE/");
    window.localStorage.setItem("alertTitle", "UnilogMobileApp");
    window.localStorage.setItem("ACCESS_TOKEN", "");
    window.localStorage.setItem("REFRESH_TOKEN",""); 

  this.BASEURL = window.localStorage.getItem("BASEURL");
  this.CATIMG = window.localStorage.getItem("CATIMG");
    this.getCimmToken();
    }
    getCimmToken() {
      this.myprovider.getAccessToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
      .subscribe(
        data =>{
        window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
        window.localStorage.setItem("REFRESH_TOKEN", data.refresh_token);  
        //console.log("Acceess token stored : " + window.localStorage.getItem("ACCESS_TOKEN"));
       // console.log("refresh token stored : " + window.localStorage.getItem("REFRESH_TOKEN"));
        this.getProductCategory();
        this.getBannerImages();
        } ,
        error =>  {
          // console.log("Token Has been Expired generating a new token");
          if(error == "AccessTokenExpired"){
            this.generateRefreshToken();
          }
          else if(error == "RefreshTokenExpired"){
            this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
            this.getCimmToken();
          }
          else{
            if(error.indexOf('html') >= 0){
             this.htmlErrorContent = error.split("<body>")[1];
             this.htmlErrorContent = this.htmlErrorContent.replace('<img src=','<img src="'+window.localStorage.getItem("APIURL")+'maintenance/logo.png');
             this.myprovider.loadingContentHide();
            }
            else{
            this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
            this.myprovider.loadingContentHide();
            }
          }
        });
        //console.log("refresh token stored : " + this.errorMessage);
    }

    scan(){
      this.options = {
          prompt : "Scan your barcode "
      }
      this.barcodeScanner.scan(this.options).then((barcodeData) => {
    
          console.log(barcodeData);
          this.scanData = barcodeData.text;
          this.searchGeneral(13,this.scanData);
      }, (err) => {
          console.log("Error occured : " + err);
      });         
    }

    generateRefreshToken() {
      this.myprovider.refreshToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
      .subscribe(
        data =>{
          window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
          this.getProductCategory();
        } ,
        error =>  this.errorMessage = <any>error);
        //console.log("refresh token stored : " + this.errorMessage);
    }
    getProductCategory() {
      this.myprovider.getContent("api/ecomm/v1/catalogs/mine/categories")
         .subscribe(
          categories =>{
           //console.log(categories);
            this.categories = categories.content;
            this.myprovider.loadingContentHide();
           } ,
           error =>  {
            // console.log("Token Has been Expired generating a new token");
            if(error == "AccessTokenExpired"){
              this.generateRefreshToken();
            }
            else if(error == "RefreshTokenExpired"){
              this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
              this.getCimmToken();
            }
            else{
              //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
              //this.myprovider.loadingContentHide();
            }
          })
    }
    getBannerImages() {
      // this.slideData = [{ image: "banner5.png" },{ image: "banner6.png" },{ image: "banner7.png" },{ image: "banner8.png" },{ image: "banner9.png" }];
      this.myprovider.getContent("api/ecomm/v1/banners/161")
         .subscribe(
          slideData =>{
            this.slideData = slideData.content.bannerValues;
           // this.myprovider.loadingContentHide();
           } ,
           error =>  {
           // console.log("Token Has been Expired generating a new token");
           if(error == "AccessTokenExpired"){
             this.generateRefreshToken();
           }
           else if(error == "RefreshTokenExpired"){
             this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
             this.getCimmToken();
           }
           else{
             if(error.indexOf('html') >= 0){
              this.htmlErrorContent = error.split("<body>")[1];
              this.htmlErrorContent = this.htmlErrorContent.replace('<img src=','<img src="'+window.localStorage.getItem("APIURL")+'maintenance/logo.png');
              this.myprovider.loadingContentHide();
             }
             else{
             this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
             this.myprovider.loadingContentHide();
             }
           }
         })



    }
    
//   ionViewDidLoad() {
//     alert("ionViewDidLoad == 2nd only when a view is stored in memory");
//   }
//   ionViewWillEnter(){
//     alert("ionViewWillEnter == 3rd entering a page, before it becomes the active");
//   }
//   ionViewDidEnter(){
//     alert("ionViewDidEnter == 4th after it becomes the active page");
//   }
//   ionViewWillLeave(){
//     alert("ionViewWillLeave == 6th () before it stops being the active");
//   }
//   ionViewDidLeave(){
//     alert("ionViewDidLeave == 7th (next page) after it stops being the active one");
//   }
//   ionViewWillUnload(){
//     alert("ionViewWillUnload ==  when a view is going to be completely removed");
//   }
// //Nav guards

// ionViewCanEnter(){
//   alert("ionViewCanEnter == 1st after it stops being the active one");
// }
// ionViewCanLeave(){
//   alert("ionViewCanLeave ==   5th(going out) when a view is going to be completely removed");
// }


// ionViewWillAppear(){
//   alert("ionWillAppear ");
// }


// ionViewDidAppear(){
//   alert("ionViewDidAppear ==  when a view is going to be completely removed");
// }

// ionViewWillDisappear(){
//   alert("ionWillAppear ");
// }




//  Navigation 
navToCartPage(){
  this.navCtrl.push(CartPage);
}


subCategory(id,name){
//service
this.myprovider.loadingContent('');
this.myprovider.getContent("api/ecomm/v1/catalogs/mine/categories/"+id+'/children')
         .subscribe(
          categories =>{
           //console.log(categories);
           if(categories.content.length > 0){
           
            this.navCtrl.push(SubcategoryPage,{subcategoryData:categories.content});
           }
           else{
            
            this.searchGeneral(13,name)
            //this.navCtrl.push(ProductgridPage);
           }
           } ,
           error =>  {
            this.myprovider.loadingContentHide();
            //console.log("Token Has been Expired generating a new token");
           if(error == "AccessTokenExpired"){
             this.generateRefreshToken();
           }
           else if(error == "RefreshTokenExpired"){
             this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
             this.getCimmToken();
           }
           else{
             this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
             this.myprovider.loadingContentHide();
           }
         })
}
productCategory(){
  this.navCtrl.push(ProductcategoriesPage);
}
searchKeyword(){
  this.myprovider.generalSearch(this.seachInput);
}

searchKeyword_popup(){
  //this.navCtrl.push(SearchpopupPage);
  this.rest.myheader = true;
}
hidesearchKeyword_popup(){
  //this.navCtrl.push(SearchpopupPage);
  this.rest.myheader = false;
}

checkPermission(){
  this.myprovider.getPermission();
}
listenvoice(){
  this.myprovider.getPermission();
  this.value =this.myprovider.listen();
}

startListens(){
  this.myprovider.getPermission();
  this.myprovider.startListen();
}
stopListens(){
  this.myprovider.stopListen();
}

openCamera(){
	//this.myprovider.openCamera();
	this.openCamera1(this);
}
   openCamera1(instance){
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation:true
    }

    this.camera.getPicture(options).then((imageData) => {
     // imageData is either a base64 encoded string or a file URI
     // If it's base64:
     let base64Image = 'data:image/jpeg;base64,' + imageData;
     instance.imageSelected=true;
     instance.imageData=base64Image;

     //For vision API start
      var type = "LABEL_DETECTION";

      // Strip out the file prefix when you convert to json.
      var jsonData ='{"requests":[{"image":{"content":"'+imageData+'"},"features":[{"type":"'+type+'","maxResults": 200}]}]}'
      instance.callVisionAPI(jsonData,instance);
      //instance.visionAPIresponcePopup(jsonData);

      //For vision API end

    }, (err) => {
     // Handle error
    });
  }

  callVisionAPI(json,instance){
    this.myprovider.loadingContent('');
    var api_key="AIzaSyCAVrBL7xRqYS4q3bgUIKgxhGeuAJpwDl0";
    var url="https://vision.googleapis.com/v1/images:annotate?key=" + api_key;

    this.myprovider.postRequest(url,json)
    .subscribe(
         data => {
         console.log(data);
         this.myprovider.loadingContentHide();
          instance.visionAPIresponcePopup(data.responses)
         },
         error =>  {
          this.myprovider.loadingContentHide();
         var errorMessage = <any>error
         });
  }

  visionAPIresponcePopup(data){
    let actionSheet = this.actionSheetCtrl.create({
       title: 'Results'
     });


	  var t=['wire','pipe','wheel','drum','wire','pipe','wheel','drum','wire','pipe','wheel','drum','wire','pipe','wheel','drum'];
     this.presentPopover(this,data[0].labelAnnotations);
    console.log('iconPhotoEnqueryClick')
   
  }
presentPopover(myEvent,t) {
  let options={
  cssClass:'popoverAlert',
  showBackdrop:true
  }
  let popover = this.popoverCtrl.create(PopoverPage,t,options);
  popover.present({
    ev: myEvent
  });
}
//refresher

doRefresh(refresher) {
  console.log('Begin async operation', refresher);

  setTimeout(() => {
    this.getProductCategory();
    this.getBannerImages()
    refresher.complete();
  }, 2000);
}


searchGeneral(keyCode,item){
debugger
  if(item){

  if(keyCode == 13){
    if(item.length>0 ){
      this.seachInput = item;
    }
    this.myprovider.loadingContentHide();
    this.myprovider.loadingContent('');
   //this.seachInput = encodeURI(this.seachInput);
   if(this.seachInput.indexOf('ABB') > -1)
   this.seachInput = this.seachInput.replace("ABB ","");
    this.myprovider.getContent("api/ecomm/v1/catalogs/mine/items?query="+this.seachInput)
    .subscribe(
     searchResult =>{
        if(searchResult.content.length == 1){
        this.searchResult = searchResult.content[0];      
        this.myprovider.setValue(this.searchResult);
        this.navCtrl.push(ProductdetailPage);
         }
         else if(searchResult.content.length > 1){
         this.searchResult = searchResult.content;      
         this.myprovider.setValue(this.searchResult);  
         this.navCtrl.push(ProductgridPage);
        }
        else if(searchResult.content.length == 0){
          this.myprovider.loadingContentHide();

          alert("no item found !..ß");
        }
      } ,
      error =>  {
        this.myprovider.loadingContentHide();
        console.log(error);
        if(error == "AccessTokenExpired"){
          this.generateRefreshToken();
        }
        else if(error == "RefreshTokenExpired"){
          this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
          this.getCimmToken();
        }
        else if(error == "noResource"){
          this.myprovider.loadingContentHide();
          alert("no item found !..ß");
        }
        else{
          this.myprovider.loadingContentHide();
          console.log(error);
          //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
          //this.myprovider.loadingContentHide();
        }
     })

    
  }
}
else{
  this.myprovider.loadingContentHide();
  return false;
}
}




}
