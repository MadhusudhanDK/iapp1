import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {ProductcategoriesPage} from '../productcategories/productcategories'
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the ChangeshipaddressPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-changeshipaddress',
  templateUrl: 'changeshipaddress.html',
})
export class ChangeshipaddressPage {
  countries=[];
  errorMessage: string;
  loader;
  seachInput;
  filterCountries:string[];
  constructor(public navCtrl: NavController, public navParams: NavParams, public rest: RestProvider, public myprovider:MyprovidersProvider) {

  }

  ionViewDidLoad() {
    this.getCountries();
  }
  getCountries() {
    this.myprovider.getCountries('test')
    .subscribe(
      countries =>{
      
       this.countries = countries;
       this.filterCountries = countries;
    
      } ,
      error =>  this.errorMessage = <any>error);
  }
  productCatagory(){
    this.navCtrl.push(ProductcategoriesPage);
  }


   //search item
   filterTechnologies(param : any) : void
   {
    this.countries = this.myprovider.searchByEntry(param,this.filterCountries);
  
   } 

}
