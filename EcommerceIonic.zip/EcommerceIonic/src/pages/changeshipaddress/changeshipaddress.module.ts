import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ChangeshipaddressPage } from './changeshipaddress';

@NgModule({
  declarations: [
    // ChangeshipaddressPage,
  ],
  imports: [
    IonicPageModule.forChild(ChangeshipaddressPage),
  ],
})
export class ChangeshipaddressPageModule {}
