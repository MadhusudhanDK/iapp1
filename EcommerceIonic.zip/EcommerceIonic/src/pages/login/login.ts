import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import { ForgotpasswordPage } from '../forgotpassword/forgotpassword';
import { RegistertypePage } from '../registertype/registertype';

import {FormBuilder, FormGroup, Validators, AbstractControl} from '@angular/forms';
import { ProductcategoriesPage } from '../productcategories/productcategories';
import { HomePage } from '../home/home';
import { TabsPage } from '../tabs/tabs';

// import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import { AngularFireAuth } from 'angularfire2/auth';

import firebase from 'firebase';
import { CartPage } from '../cart/cart';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  seachInput;
  formgroup:FormGroup;
  userName:AbstractControl;
  password:AbstractControl;
  // tabBarElement;

  constructor(private fire :AngularFireAuth,public navCtrl: NavController,public myprovider: MyprovidersProvider, public formbuilder:FormBuilder, public rest: RestProvider) {
    this.formgroup=formbuilder.group({
      userName:['',Validators.required],
      password:['',Validators.required]

    });
    this.userName=this.formgroup.controls['userName'];
    this.password=this.formgroup.controls['password'];
    // this.tabBarElement = document.querySelector('#tabs ion-tabbar-section');
    
  }

  ionViewDidEnter() {
    // this.tabBarElement.style.display = 'none';
  }

  ionViewWillLeave(){
      // this.tabBarElement.style.display = 'block';
  }
  
  navToForgotPassword(){
    this.navCtrl.push(ForgotpasswordPage);
  }
  navToRegisterType(){
    this.navCtrl.push(RegistertypePage);
  }

  callLogin(){
    this.rest.loginState = true;
    this.navCtrl.push(HomePage);
    // this.fire.auth.signInWithEmailAndPassword(this.userName.value,this.password.value)
    // .then(data =>{
    //   console.log("got data == ",data);
    //   this.rest.loginState = true;
    //   this.navCtrl.push(HomePage);
    //   alert("welcome, "+this.fire.auth.currentUser.email);
    // })
    // .catch(error =>{
    //   alert(error);
    //   console.log("got error == ",error)
    // });
    // console.log("would register user with == ",this.userName.value,this.password.value);

   // 
  
  }

  registerNow(){
    this.fire.auth.createUserAndRetrieveDataWithEmailAndPassword(this.userName.value,this.password.value)
    .then(data =>{
      console.log("got data == ",data);
      alert("Successfuly Registered");
    })
    .catch(error =>{
      alert(error);
      console.log("got error == ",error)
    });
    console.log("would register user with == ",this.userName.value,this.password.value);
  }
  navToHome(){
    // this.navCtrl.push(TabsPage);
    this.navCtrl.setRoot(TabsPage);
  }




  logoutwithFb(){
    this.fire.auth.signOut();
  }

}
