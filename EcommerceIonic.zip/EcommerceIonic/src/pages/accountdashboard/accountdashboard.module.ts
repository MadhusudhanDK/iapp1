import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AccountdashboardPage } from './accountdashboard';

@NgModule({
  declarations: [
    // AccountdashboardPage,
  ],
  imports: [
    IonicPageModule.forChild(AccountdashboardPage),
  ],
})
export class AccountdashboardPageModule {}
