import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams,ActionSheetController } from 'ionic-angular';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { PopoverController } from 'ionic-angular';
import { LoginPage } from '../login/login';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the AccountdashboardPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-accountdashboard',
  templateUrl: 'accountdashboard.html',
})
export class AccountdashboardPage {
  imageData:any;
  AccountDash:string
  countries: string[];
  errorMessage: string;
  loader;
  seachInput
  Name;registeredDate;officePhone;emailAddress;address;
  shipTos: string[];
  billTos: string[];
  BASEURL = window.localStorage.getItem("BASEURL");
  CATIMG = window.localStorage.getItem("CATIMG");
  constructor(public navCtrl: NavController, public navParams: NavParams, public myprovider:MyprovidersProvider, public actionSheetCtrl:ActionSheetController,private camera: Camera,public popoverCtrl: PopoverController,public rest: RestProvider) {
    this.myprovider.loadingContent('');
    this.getUserInformation();
    this.getShipingInformation();
  }
  getUserInformation() {
    this.myprovider.getContent("api/ecomm/v1/users/me")
       .subscribe(
        data =>{
         console.log("dashboard  "+   data.content.firstName);
         this.Name = data.content.firstName + " " + data.content.lastName;
         this.address = data.content.address1 + " ," + data.content.city+ " ," + data.content.state+ " ," + data.content.countryCode+ " ," + data.content.zipCode+ " ," + data.content.country;
         this.emailAddress = data.content.emailAddress;
         this.officePhone = data.content.officePhone;
         this.registeredDate = data.content.registeredDate;
        this.myprovider.loadingContentHide();
         } ,
         error =>  {
          console.log("Token Has been Expired generating a new token");
         if(error == "AccessTokenExpired"){
           this.generateRefreshToken();
         }
         else if(error == "RefreshTokenExpired"){
           this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
          // this.getCimmToken();
         }
         else{
           this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
           this.myprovider.loadingContentHide();
         }
       })
  }
  getShipingInformation() {
    //this.myprovider.loadingContent('');
    this.myprovider.getContent("api/ecomm/v1/users/me/shiptos")
       .subscribe(
        shipTos =>{
         console.log(shipTos);
          this.shipTos = shipTos.content;
          //this.myprovider.loadingContentHide();
         } ,
         error =>  {
          console.log("Token Has been Expired generating a new token");
         if(error == "AccessTokenExpired"){
           this.generateRefreshToken();
         }
         else if(error == "RefreshTokenExpired"){
           this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
           //this.getCimmToken();
         }
         else{
           this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
           this.myprovider.loadingContentHide();
         }
       })
  }
  generateRefreshToken() {
    this.myprovider.refreshToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
    .subscribe(
      data =>{
        window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
        this.getShipingInformation();
      } ,
      error =>  this.errorMessage = <any>error);
      console.log("refresh token stored : " + this.errorMessage);
  }
  ionViewDidLoad() {
  }

  ionViewWillEnter(){
    this.AccountDash = "Profile";
  }
  segmentChanged(obj){
      alert(obj);
  }

  refreshShipToList(){
    alert("refresh list");
  }

  // presentPopover(myEvent) {
  //   let popover = this.popoverCtrl.create(LoginPage);
  //   popover.present({
  //     ev: myEvent
  //   });
  // }

  openCamera(){
    //this.myprovider.openCamera();
    this.openCamera1(this);
  }
  openGallery(){
    //this.myprovider.openGallery();
    this.openGallery1(this);
  }
    Uploadphoto(){
    let actionSheet = this.actionSheetCtrl.create({
       title: 'Camera',
       buttons: [
         {
           text: 'Camera',
           handler: () => {
             console.log('Camera');
             this.openCamera();
           }
         },
         {
           text: 'Photo/Gallery',
           handler: () => {
             console.log('Photo/Gallery');
             this.openGallery();
           }
         },
       ]
     });
  
     actionSheet.present();
    console.log('iconPhotoEnqueryClick')
   }
  
    openCamera1(instance){
      const options: CameraOptions = {
        quality: 100,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE,
        correctOrientation:true
      }
  
      this.camera.getPicture(options).then((imageData) => {
       // imageData is either a base64 encoded string or a file URI
       // If it's base64:
       let base64Image = 'data:image/jpeg;base64,' + imageData;
       instance.imageSelected=true;
       instance.imageData=base64Image;
      }, (err) => {
       // Handle error
      });
    }
  
    openGallery1(instance){
      const options: CameraOptions = {
        quality: 100,
        sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE
      }
  
      this.camera.getPicture(options).then((imageData) => {
       // imageData is either a base64 encoded string or a file URI
       // If it's base64:
       let base64Image = 'data:image/jpeg;base64,' + imageData;
       instance.imageSelected=true;
       instance.imageData=base64Image;
      }, (err) => {
       // Handle error
      });
    }




  
  
  
    getCountries() {
      this.myprovider.getCountries("test")
         .subscribe(
           countries =>{
           
            this.countries = countries;
           } ,
           error =>  this.errorMessage = <any>error);
    }



}
