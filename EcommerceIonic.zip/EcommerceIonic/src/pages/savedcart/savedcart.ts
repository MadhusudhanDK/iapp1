import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { SavedcartdetailsPage } from '../savedcartdetails/savedcartdetails';
import { CartPage } from '../cart/cart';



/**
 * Generated class for the SavedcartPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-savedcart',
  templateUrl: 'savedcart.html',
})
export class SavedcartPage {
  countries: string[];
  errorMessage: string;
  seachInput;
  constructor(public navCtrl: NavController, public navParams: NavParams, public rest: RestProvider, public myprovider: MyprovidersProvider) {
    this.myprovider.loadingContent('');
  }

 
  ionViewDidLoad() {
    this.getCountries();
  }
  getCountries() {

    this.myprovider.getCountries('savedcart')
       .subscribe(
         countries => this.countries = countries,
         error =>  this.errorMessage = <any>error);
         this.myprovider.loadingContentHide();
  }

  cartSeclect(c){
    this.myprovider.loadingContent('');
    this.rest.cartname = c.name;
    this.navCtrl.push(SavedcartdetailsPage)
  }

//  Navigation 



}
