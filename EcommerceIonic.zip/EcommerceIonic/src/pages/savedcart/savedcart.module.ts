import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SavedcartPage } from './savedcart';

@NgModule({
  declarations: [
    // SavedcartPage,
  ],
  imports: [
    IonicPageModule.forChild(SavedcartPage),
  ],
})
export class SavedcartPageModule {}
