import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, ModalController } from 'ionic-angular';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { RestProvider } from '../../providers/rest/rest';
import { CheckoutPage } from '../checkout/checkout';
import { InAppBrowser, InAppBrowserOptions } from '@ionic-native/in-app-browser';
import { HttpClient } from '@angular/common/http';
import { LoginPage } from '../login/login';
import { HelpPage } from '../help/help';
/**
 * Generated class for the CartPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-cart',
  templateUrl: 'cart.html',
})
export class CartPage {
  cartItems:any;
  errorMessage="";
  mytotal;
  alert;
  errordata="";
  checkoutdata= "";
  seachInput;
  myTemplate;
  options : InAppBrowserOptions = {
    location : 'yes',//Or 'no' 
    hidden : 'no', //Or  'yes'
    clearcache : 'yes',
    clearsessioncache : 'yes',
    zoom : 'yes',//Android only ,shows browser zoom controls 
    hardwareback : 'yes',
    mediaPlaybackRequiresUserAction : 'no',
    shouldPauseOnSuspend : 'no', //Android only 
    closebuttoncaption : 'Close', //iOS only
    disallowoverscroll : 'no', //iOS only 
    toolbar : 'yes', //iOS only 
    enableViewportScale : 'no', //iOS only 
    allowInlineMediaPlayback : 'no',//iOS only 
    presentationstyle : 'pagesheet',//iOS only 
    fullscreen : 'yes',//Windows only    
};
  constructor(public modalCtrl: ModalController,public http: HttpClient,public navCtrl: NavController,public alertCtrl : AlertController, public navParams: NavParams,public myprovider: MyprovidersProvider,public rest: RestProvider,private theInAppBrowser: InAppBrowser) {
  this.myprovider.loadingContent("");

  }

  public openWithSystemBrowser(url : string){
    let target = "_system";
    this.theInAppBrowser.create(url,target,this.options);
}



public openWithInAppBrowser(url : string){
    let target = "_blank";
    this.theInAppBrowser.create(url+"&Authorization=Bearer "+window.localStorage.getItem("ACCESS_TOKEN"),target,this.options);
}
public openWithCordovaBrowser(url : string){
    let target = "_self";
    this.theInAppBrowser.create(url,target,this.options);
} 

  ionViewDidLoad() {
    this.getCartItems();
  }

  doRefresh(refresher) {
    console.log('Begin async operation', refresher);

    setTimeout(() => {
      this.getCartItems();
      refresher.complete();
    }, 2000);
  }

  getCartItems() {
    this.myprovider.getContent("api/ecomm/v1/users/me/carts")
       .subscribe(
         cartItems =>{
           this.cartItems = cartItems.content;
           if(cartItems.content.length > 0){
            this.mytotal = cartItems.content[0].totalCartPrice;
           }else{
            this.mytotal=0;
           }
           this.rest.cartCount = cartItems.content.totalCartItems;
        	 this.myprovider.loadingContentHide();
         } ,
         error =>  {
          console.log("Token Has been Expired generating a new token");
         if(error == "AccessTokenExpired"){
           this.generateRefreshToken();
         }
         else if(error == "RefreshTokenExpired"){
           this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
          // this.getCimmToken();
         }
         else{
           this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
           this.myprovider.loadingContentHide();
         }
       })
  }

  generateRefreshToken() {
    this.myprovider.refreshToken(window.localStorage.getItem("APIURL")+"/aas/oauth/token")
    .subscribe(
      data =>{
        window.localStorage.setItem("ACCESS_TOKEN", data.access_token);
        this.getCartItems();
      } ,
      error =>  this.errorMessage = <any>error);
      console.log("refresh token stored : " + this.errorMessage);
  }

  iconRefreshClick(){
  //alert("Hi")
  }
iconDeleteClick(id){
console.log(id);
if(id==0){
 id="";
}
  let alert = this.alertCtrl.create({
    title: 'McNAUGHTON-MCKAY',
    message: 'Do you want to Delete the cart ? ',
    buttons: [
      {
        text: 'Cancel',
        role: 'cancel',
        handler: () => {
          console.log('Cancel clicked');
        }
      },
      {
        text: 'Delete',
        handler: () => {

          console.log('Buy clicked'+id);
          this.myprovider.deleteContent("api/ecomm/v1/users/me/carts/"+id)
         .subscribe(
          categories =>{
           console.log(categories);
           this.success(1);
           } ,
           error =>  this.errorMessage = <any>error);



        }
      }
    ]
  });
  
  alert.present();
  this.getCartItems();
}
success(arg){
  let alert = this.alertCtrl.create({
    title: 'Unilog',
    subTitle: 'Item Deleted',
    buttons: ['Ok']
  });
  alert.present();
  this.getCartItems();
}


loadCheckoutProcess(){
  this.myprovider.loadingContent('');

  // this.getCheckoutData("https://gerriestage.cimm2.com/checkout.slt?authcode=cimmesb")
  this.http.get("https://gerriestage.cimm2.com/checkout.slt?authcode=cimmesb",{headers: {'Authorization': 'Bearer '+window.localStorage.getItem("ACCESS_TOKEN")}}) 
  .map((html:any) => this.myTemplate = html)
  .subscribe(
    
   data =>{
    this.myprovider.loadingContentHide();

    console.log(this.myTemplate);console.log("data"+data);
    console.log("loadCheckoutProcess = "+data);
    alert(data);
    
     this.checkoutdata = data.content;
     this.myprovider.loadingContentHide();
    } ,
    error =>  {
      debugger;
      console.log(error.error.text)
      this.errordata =error.error.text;
this.myprovider.setValue(this.errordata);
this.myprovider.loadingContentHide();

this.presentModal();

      


     if(error == "AccessTokenExpired"){
       this.generateRefreshToken();
     }
     else if(error == "RefreshTokenExpired"){
       this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
     }
     else{
       //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
       //this.myprovider.loadingContentHide();
     }
   })
}

presentModal() {
  const modal = this.modalCtrl.create(HelpPage);
  modal.present();
}




}
