import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PhotoenqueryPage } from './photoenquery';

@NgModule({
  declarations: [
    // PhotoenqueryPage,
  ],
  imports: [
    IonicPageModule.forChild(PhotoenqueryPage),
  ],
})
export class PhotoenqueryPageModule {}
