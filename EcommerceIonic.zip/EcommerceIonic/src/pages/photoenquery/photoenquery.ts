


import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,LoadingController, ActionSheetController} from 'ionic-angular';

import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { CartPage } from '../cart/cart';

/**
 * Generated class for the PhotoenqueryPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-photoenquery',
  templateUrl: 'photoenquery.html',
})
export class PhotoenqueryPage {

imageSelected=false;
seachInput;
  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController, public rest: RestProvider,public myprovider: MyprovidersProvider, public actionSheetCtrl:ActionSheetController,private camera: Camera ){
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PhotoenqueryPage');
  }

openCamera(){
	//this.myprovider.openCamera();
	this.openCamera1(this);
}
openGallery(){
	//this.myprovider.openGallery();
	this.openGallery1(this);
}
  Uploadphoto(){
  let actionSheet = this.actionSheetCtrl.create({
     title: 'Camera',
     buttons: [
       {
         text: 'Camera',
         handler: () => {
           console.log('Camera');
           this.openCamera();
         }
       },
       {
         text: 'Photo/Gallery',
         handler: () => {
           console.log('Photo/Gallery');
           this.openGallery();
         }
       },
     ]
   });

   actionSheet.present();
  console.log('iconPhotoEnqueryClick')
 }

  openCamera1(instance){
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation:true
    }

    this.camera.getPicture(options).then((imageData) => {
     // imageData is either a base64 encoded string or a file URI
     // If it's base64:
     let base64Image = 'data:image/jpeg;base64,' + imageData;
     instance.imageSelected=true;
     instance.imageData=base64Image;
    }, (err) => {
     // Handle error
    });
  }

  openGallery1(instance){
    const options: CameraOptions = {
      quality: 100,
      sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    }

    this.camera.getPicture(options).then((imageData) => {
     // imageData is either a base64 encoded string or a file URI
     // If it's base64:
     let base64Image = 'data:image/jpeg;base64,' + imageData;
     instance.imageSelected=true;
     instance.imageData=base64Image;
    }, (err) => {
     // Handle error
    });
  }

}

