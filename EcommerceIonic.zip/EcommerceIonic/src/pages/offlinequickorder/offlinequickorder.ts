import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams ,AlertController} from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { CartPage } from '../cart/cart';
 
/**
 * Generated class for the OfflinequickorderPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-offlinequickorder',
  templateUrl: 'offlinequickorder.html',
})
export class OfflinequickorderPage {
  notes=[];
  seachInput;

  constructor(public navCtrl: NavController, public rest: RestProvider, public myprovider: MyprovidersProvider,public navParams: NavParams, public alertCtrl: AlertController) {
     
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad OfflinequickorderPage');
  }

  addToLocalDb(){
    alert("d");
  }
  removeFromLocalDb(){
    alert("d");
  }
  addRow(){
    alert("add row");
  }
  

  addNote(){
     let prompt = this.alertCtrl.create({
        title: 'Add data',
        inputs: [{
            name: 'sku',
            placeholder: 'sku',
            type: 'text'
        },
        {
          name: 'qty',
          placeholder: 'qty',
          type: 'text'
        }],
        buttons: [{
                text: 'Cancel'
            },{
                text: 'Add',
                handler: data => {
                    console.log(data);
                    if(data.sku.length || data.qty.length ){
                      this.notes.push(data);  
                    }else{
                      this.myprovider.alert("","Please enter sku and Qty");
                      
                    }
                                    
                }
            }]
    });

    prompt.present();
}

editNote(note){
console.log(note);
    let prompt = this.alertCtrl.create({
        title: 'Edit Note',
        inputs: [{
          name: 'sku',
          placeholder: 'sku',
          type: 'text',
          value : note.sku 
      },
      {
        name: 'qty',
        placeholder: 'qty',
        type: 'text',
        value : note.qty 
      }],
        buttons: [
            {
                text: 'Cancel'
            },
            {
                text: 'Save',
                handler: data => {
                  if(data.sku.length || data.qty.length ){
                      let index = this.notes.indexOf(note);

                      if(index > -1){
                        this.notes[index] = data;
                      }
                  }else{
                    alert("Please enter sku and Qty");
                  }

                }
            }
        ]
    });

    prompt.present();      

}

deleteNote(note){

    let index = this.notes.indexOf(note);

    if(index > -1){
        this.notes.splice(index, 1);
    }
}


  
}
