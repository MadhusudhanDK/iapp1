import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { OfflinequickorderPage } from './offlinequickorder';

@NgModule({
  declarations: [
    // OfflinequickorderPage,
  ],
  imports: [
    IonicPageModule.forChild(OfflinequickorderPage),
  ],
})
export class OfflinequickorderPageModule {}
