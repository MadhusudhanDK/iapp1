import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RegistertypePage } from './registertype';

@NgModule({
  declarations: [
    // RegistertypePage,
  ],
  imports: [
    IonicPageModule.forChild(RegistertypePage),
  ],
})
export class RegistertypePageModule {}
