import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { RestProvider } from '../../providers/rest/rest';
import { MyprovidersProvider } from  '../../providers/myproviders/myproviders';
import { OrderconfirmationPage } from '../orderconfirmation/orderconfirmation';
import { CartPage } from '../cart/cart';
/**
 * Generated class for the ConfirmorderPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-confirmorder',
  templateUrl: 'confirmorder.html',
})
export class ConfirmorderPage {
  seachInput;
  cartData:any;
  errorMessage="";
  constructor(public navCtrl: NavController, public navParams: NavParams,public myprovider: MyprovidersProvider,public rest: RestProvider) {
  this.myprovider.loadingContent("");

  }

  ionViewDidLoad() {
    this.getCountries();
  }

  getCountries() {
    this.myprovider.getCountries("test")
       .subscribe(
         countries =>{
         
         	this.cartData = countries;
         	this.myprovider.loadingContentHide();
         } ,
         error =>  this.errorMessage = <any>error);
  }

  OrderConfirmation(){
this.navCtrl.push(OrderconfirmationPage);
  }
   

}
