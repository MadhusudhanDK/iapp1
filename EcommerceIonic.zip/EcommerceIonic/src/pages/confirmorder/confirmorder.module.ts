import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConfirmorderPage } from './confirmorder';

@NgModule({
  declarations: [
    // ConfirmorderPage,
  ],
  imports: [
    IonicPageModule.forChild(ConfirmorderPage),
  ],
})
export class ConfirmorderPageModule {}
