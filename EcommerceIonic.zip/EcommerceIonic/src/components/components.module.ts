import { NgModule } from '@angular/core';
import { MyHeaderComponent } from './my-header/my-header';
@NgModule({
	// declarations: [MyHeaderComponent,MyHeaderComponent],
	declarations: [],
	imports: [],
	exports: []
})
export class ComponentsModule {}
