import { Component,Input,Output,EventEmitter } from '@angular/core';
import { RestProvider } from '../../providers/rest/rest';
import { CartPage } from '../../pages/cart/cart';
import { NavController, ActionSheetController, PopoverController, NavParams, ViewController } from 'ionic-angular';
import { MyprovidersProvider } from '../../providers/myproviders/myproviders';
import { ProductgridPage } from '../../pages/productgrid/productgrid';
import { ProductdetailPage } from '../../pages/productdetail/productdetail';
import { BarcodeScanner ,BarcodeScannerOptions } from '@ionic-native/barcode-scanner';
import { Camera,CameraOptions} from '@ionic-native/camera';



/**
 * Generated class for the MyHeaderComponent component.
 *
 * See https://angular.io/api/core/Component for more info on Angular
 * Components.
 */

// @Component({
//   template: `
  
//   	<h4 class="heading">Results</h4>
//     <ion-list no-lines>
//     	<ion-item *ngFor="let item of data" tappable (click)="itemSelected(item)">
// 		  {{ item.description }}
		  
// 	  	</ion-item>  
// 	</ion-list>
//   `
// })

export  class PopoverPage {
  seachInput;
  searchResult;
	data;
  constructor(public navCtrl_: NavController, public viewCtrl: ViewController,public navParams: NavParams,public myprovider: MyprovidersProvider) {
  	this.data=this.navParams.data;
  }

  close() {
    this.viewCtrl.dismiss();
  }

  itemSelected(item){
    this.myprovider.dataselected(item);
    this.close();
    this.searchGeneral(13,item);
  }

searchGeneral(keyCode,item){
 
  if(keyCode == 13){
    if(item.length>0 ){
      this.seachInput = item;
    }
    this.myprovider.loadingContentHide();
    this.myprovider.loadingContent('');
   //this.seachInput = encodeURI(this.seachInput);
    this.myprovider.getContent("api/ecomm/v1/catalogs/mine/items?query="+this.seachInput)
    .subscribe(
     searchResult =>{
        if(searchResult.content.length == 1){
        this.searchResult = searchResult.content[0];      
        this.myprovider.setValue(this.searchResult);
        this.navCtrl_.push(ProductdetailPage);
         }
         else if(searchResult.content.length > 1){
         this.searchResult = searchResult.content;      
         this.myprovider.setValue(this.searchResult);  
         this.navCtrl_.push(ProductgridPage);
        }
        else if(searchResult.content.length == 0){
          this.myprovider.loadingContentHide();

          alert("no item found !..ß");
        }
      } ,
      error =>  {
        
          console.log(error);
          //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
          //this.myprovider.loadingContentHide();
        
     })

    
  }
}
}


@Component({
  selector: 'my-header',
  templateUrl: 'my-header.html'
})
export class MyHeaderComponent {
  @Output()
  authorClick: EventEmitter<String> = new EventEmitter<String>();
  @Input() myText;
  seachInput;
  searchResult;
  text: string;
  scanData : {};
  encodedData : {} ;
  value;
  options :BarcodeScannerOptions;

  constructor(private barcodeScanner: BarcodeScanner,private rest:RestProvider,public navCtrl: NavController,private myprovider:MyprovidersProvider,private camera: Camera,public actionSheetCtrl:ActionSheetController,public popoverCtrl: PopoverController) {
    console.log('Hello MyHeaderComponent Component');
    this.text = 'Hello World';
  }
  onClick(){
   alert("ClIcK")
  }
  ngAfterViewInit(){
    this.text = this.myText;
  }

  navToCartPage(){
    this.navCtrl.push(CartPage);
  }
  searchKeyword(){
    this.myprovider.generalSearch(this.seachInput);
  }
  searchKeyword_popup(){
    //this.navCtrl.push(SearchpopupPage);
    this.rest.myheader = true;
  }
  hidesearchKeyword_popup(){
    //this.navCtrl.push(SearchpopupPage);
    this.rest.myheader = false;
  }


checkPermission(){
  this.myprovider.getPermission();
}
listenvoice(){
  this.myprovider.getPermission();
  this.value =this.myprovider.listen();
}

startListens(){
  this.myprovider.getPermission();
  this.myprovider.startListen();
}
stopListens(){
  this.myprovider.stopListen();
}

searchGeneral(keyCode,item){
  if(item){
  if(keyCode == 13){
    this.myprovider.loadingContent('');
    if(item.length>0 ){
      this.seachInput = item;
    }
   //this.seachInput = encodeURI(this.seachInput);
   if(this.seachInput.indexOf('ABB') > -1)
   this.seachInput = this.seachInput.replace("ABB ","");
    this.myprovider.getContent("api/ecomm/v1/catalogs/mine/items?query="+this.seachInput)
    .subscribe(
     searchResult =>{
        if(searchResult.content.length == 1){
        this.searchResult = searchResult.content[0];      
        this.myprovider.setValue(this.searchResult);
        this.navCtrl.push(ProductdetailPage);
         }
         else if(searchResult.content.length > 1){
         this.searchResult = searchResult.content;      
         this.myprovider.setValue(this.searchResult);  
         this.navCtrl.push(ProductgridPage);
        }
        else if(searchResult.content.length == 0){
          this.myprovider.loadingContentHide();

          alert("no item found !..ß");
        }
      } ,
      error =>  {
        this.myprovider.loadingContentHide();
        console.log(error);
        if(error == "AccessTokenExpired"){
         // this.generateRefreshToken();
        }
        else if(error == "RefreshTokenExpired"){
          this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
         // this.getCimmToken();
        }
        else if(error == "noResource"){
          this.myprovider.loadingContentHide();
          alert("no item found !..ß");
        }
        else{
          this.myprovider.loadingContentHide();
          console.log(error);
          //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
          //this.myprovider.loadingContentHide();
        }
     })

    
  }
}
else{
  this.myprovider.loadingContentHide();
  return false;
}
}


//scan
scan(){
  this.options = {
      prompt : "Scan your barcode "
  }
  this.barcodeScanner.scan(this.options).then((barcodeData) => {

      console.log(barcodeData);
      this.scanData = barcodeData.text;
      this.searchGeneral(13,this.scanData);
  }, (err) => {
      console.log("Error occured : " + err);
  });         
}



openCamera(){
	//this.myprovider.openCamera();
	this.openCamera1(this);
}
   openCamera1(instance){
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE,
      correctOrientation:true
    }

    this.camera.getPicture(options).then((imageData) => {
     // imageData is either a base64 encoded string or a file URI
     // If it's base64:
     let base64Image = 'data:image/jpeg;base64,' + imageData;
     instance.imageSelected=true;
     instance.imageData=base64Image;

     //For vision API start
      var type = "LABEL_DETECTION";

      // Strip out the file prefix when you convert to json.
      var jsonData ='{"requests":[{"image":{"content":"'+imageData+'"},"features":[{"type":"'+type+'","maxResults": 200}]}]}'
      instance.callVisionAPI(jsonData,instance);
      //instance.visionAPIresponcePopup(jsonData);

      //For vision API end

    }, (err) => {
     // Handle error
    });
  }

  callVisionAPI(json,instance){
    this.myprovider.loadingContent('');
    var api_key="AIzaSyCAVrBL7xRqYS4q3bgUIKgxhGeuAJpwDl0";
    var url="https://vision.googleapis.com/v1/images:annotate?key=" + api_key;

    this.myprovider.postRequest(url,json)
    .subscribe(
         data => {
         console.log(data);
         this.myprovider.loadingContentHide();
          instance.visionAPIresponcePopup(data.responses)
         },
         error =>  {
          this.myprovider.loadingContentHide();
         var errorMessage = <any>error
         });
  }

  visionAPIresponcePopup(data){
    let actionSheet = this.actionSheetCtrl.create({
       title: 'Results'
     });


	  var t=['wire','pipe','wheel','drum','wire','pipe','wheel','drum','wire','pipe','wheel','drum','wire','pipe','wheel','drum'];
     this.presentPopover(this,data[0].labelAnnotations);
    console.log('iconPhotoEnqueryClick')
   
  }
presentPopover(myEvent,t) {
  let options={
  cssClass:'popoverAlert',
  showBackdrop:true
  }
  let popover = this.popoverCtrl.create(PopoverPage,t,options);
  popover.present({
    ev: myEvent
  });
}




}
