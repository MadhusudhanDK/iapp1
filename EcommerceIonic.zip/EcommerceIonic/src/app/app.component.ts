import { Component, ViewChild, NgZone } from '@angular/core';
import { Platform, NavController,Nav, ToastController } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LoadingController } from 'ionic-angular';
import { RestProvider } from '../providers/rest/rest';
import { TabsPage } from '../pages/tabs/tabs';
import { LoginPage } from '../pages/login/login';
import { MyprovidersProvider } from '../providers/myproviders/myproviders';
import { MyAccountPage } from '../pages/my-account/my-account';
import { OtherappsPage } from '../pages/otherapps/otherapps';
import { PhotoenqueryPage } from '../pages/photoenquery/photoenquery';
import { ProductcategoriesPage } from '../pages/productcategories/productcategories';
import { SavedcartPage } from '../pages/savedcart/savedcart';
import { ProductgroupPage } from '../pages/productgroup/productgroup';
import { BarcodeScanner ,BarcodeScannerOptions } from '@ionic-native/barcode-scanner';
import { SearchPage } from '../pages/search/search';
import { MenuForAppPage } from '../pages/menu-for-app/menu-for-app';
import { Push, PushObject, PushOptions } from '@ionic-native/push';
import { tap } from 'rxjs/operators';
import { PayPal, PayPalPayment, PayPalConfiguration,PayPalPaymentDetails } from '@ionic-native/paypal';
import {Http,Headers,RequestOptions,RequestMethod} from '@angular/http';
import { OfflinequickorderPage } from '../pages/offlinequickorder/offlinequickorder';
import { HomePage } from '../pages/home/home';
import { LocationsPage } from '../pages/locations/locations';
import { CartPage } from '../pages/cart/cart';
import { ContactPage } from '../pages/contact/contact';
import { BrandsPage } from '../pages/brands/brands';
import { ManufacturerPage } from '../pages/manufacturer/manufacturer';
import { ProductdetailPage } from '../pages/productdetail/productdetail';
import { ProductgridPage } from '../pages/productgrid/productgrid';
import { AboutPage } from '../pages/about/about';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  countries: string[];
  mytoken;
  searchResult
  errorMessage: string;
  categories: string[];
  rootPage:any = HomePage;
  @ViewChild(Nav) navCtrl: Nav;
  title = "r";
  scanData : {};
  encodedData : {} ;
  options :BarcodeScannerOptions;
  constructor( platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen, public loadingCtrl: LoadingController,public myprovider: MyprovidersProvider, public rest: RestProvider,private barcodeScanner: BarcodeScanner,private push: Push, toastCtrl: ToastController,public payPal: PayPal, public http: Http) {
    platform.ready().then(() => {
    statusBar.overlaysWebView(false);
    statusBar.backgroundColorByHexString('#bfbfbf');
    // window.localStorage.setItem("APIURL", "https://cimmesbstage.cimm2.com/");
    // window.localStorage.setItem("BASEURL", "https://templatestage.cimm2.com/");
    // window.localStorage.setItem("AUTHUSER", "web");
    // window.localStorage.setItem("AUTHPWD", "web");



    splashScreen.hide();
      // Create FCM token // Not working in browser
      //  myprovider.getToken();
      //  myprovider.listenToNotifications().pipe(
      //   tap(msg => {
      //     // show a toast
      //     const toast = toastCtrl.create({
      //       message: msg.body,
      //       duration: 3000
      //     });
      //     toast.present();
      //   })
      // )
      // .subscribe()
    });
  }
  
  homePage(){
    this.navCtrl.push(HomePage);
  }
  productCategory(){
    this.navCtrl.push(ProductcategoriesPage);
  }
myAccount(){
  if(this.rest.loginState)
  this.navCtrl.push(MyAccountPage);
  else
  this.myprovider.loginPrompt(this);
}

savedCart(){
  if(this.rest.loginState)
  this.navCtrl.push(SavedcartPage);
  else
  this.myprovider.loginPrompt(this);

}
productGroup(){
  if(this.rest.loginState)
  //this.navCtrl.push(ProductgroupPage);
  this.navCtrl.push(ProductgroupPage,{"type":"view"});

  else
  this.myprovider.loginPrompt(this);

}

 logout(){
   this.myprovider.logoutGlobal();

 }
 navToLogInPage(){
  this.navCtrl.push(LoginPage);
  // this.myprovider.loginGlobal(this);
 }

 brands(){
  this.navCtrl.push(BrandsPage);
}

manufacturer(){
  this.navCtrl.push(ManufacturerPage);
}


 photoEnquiry(){
  this.navCtrl.push(PhotoenqueryPage);
 }

 viewMap(){
  this.navCtrl.push(LocationsPage);
 }

 

 otherApps(){
  this.navCtrl.push(OtherappsPage);
}
contactUs(){
  this.navCtrl.push(ContactPage);
}
navToCartPage(){
  this.navCtrl.push(CartPage);
}

search(){
  this.navCtrl.push(SearchPage);
}


//scan
scan(){
  this.options = {
      prompt : "Scan your barcode "
  }
  this.barcodeScanner.scan(this.options).then((barcodeData) => {

      console.log(barcodeData);
      this.scanData = barcodeData.text;
      this.searchGeneral(this.scanData);
  }, (err) => {
      console.log("Error occured : " + err);
  });         
}
searchGeneral(item){
  this.myprovider.getContent("api/ecomm/v1/catalogs/mine/items?query="+item)
  .subscribe(
   searchResult =>{
      if(searchResult.content.length == 1){
      this.searchResult = searchResult.content[0];      
      this.myprovider.setValue(this.searchResult);
      this.myprovider.loadingContentHide();
      this.navCtrl.push(ProductdetailPage);
       }
       else if(searchResult.content.length > 1){
       this.searchResult = searchResult.content;      
       this.myprovider.setValue(this.searchResult);  
       this.navCtrl.push(ProductgridPage);
      }
      else if(searchResult.content.length == 0){
        this.myprovider.loadingContentHide();

        alert("no item found !..ß");

      }
    } ,
    error =>  {
      console.log(error);
      if(error == "AccessTokenExpired"){
      //  this.generateRefreshToken();
      }
      else if(error == "RefreshTokenExpired"){
        this.myprovider.alert(window.localStorage.getItem("alertTitle"),"Refresh Token hasbeen Expired Redirecting to HomePage .. ?");
        //this.getCimmToken();
      }
      else if(error == "noResource"){
        this.myprovider.loadingContentHide();

        alert("no item found !..ß");
      }
      else{
        console.log(error);
        //this.myprovider.alert(window.localStorage.getItem("alertTitle"),error);
        //this.myprovider.loadingContentHide();
      }
   })
}
encodeText(){
this.barcodeScanner.encode(this.barcodeScanner.Encode.TEXT_TYPE,this.encodedData).then((encodedData) => {

    console.log(encodedData);
    this.encodedData = encodedData;

}, (err) => {
    console.log("Error occured : " + err);
});                 
}    


//end of scan 

SpeachRec(){
  this.navCtrl.push(MenuForAppPage);
}
direct(){
  this.navCtrl.push(AboutPage);

}


//PAYPAL INTEGRATION
initializepaypal(){
  this.payPal.init({
    PayPalEnvironmentProduction: 'YOUR_PRODUCTION_CLIENT_ID',
    PayPalEnvironmentSandbox: 'AVFarGICtgPeCy3FStVAhzD1IzeIKqE8r2gcFz94W8s--e5FzZqmuJXdZufdyc7usBJfCckEw7SoZGMN'
  }).then(() => {
    // Environments: PayPalEnvironmentNoNetwork, PayPalEnvironmentSandbox, PayPalEnvironmentProduction
    this.payPal.prepareToRender('PayPalEnvironmentSandbox', new PayPalConfiguration({
      // Only needed if you get an "Internal Service Error" after PayPal login!
      //payPalShippingAddressOption: 2 // PayPalShippingAddressOptionPayPal
    })).then(() => {
      var paymentDetails = new PayPalPaymentDetails("50.00", "0.00", "0.00");
          let payment = new PayPalPayment("50.00", "USD", "Awesome Sauce", "Authorize", paymentDetails);
    // let payment = new PayPalPayment('3.33', 'USD', 'Description', 'Authorize');
      this.payPal.renderSinglePaymentUI(payment).then((success)=> {
        // Successfully paid
        console.log('OnSuccess Render: ' + JSON.stringify(success));
  
        let data = JSON.stringify(success, null, 4);
  
        let jsondata = JSON.parse(data);
        let paymentid = jsondata.response.id;
  
        console.log("paymentid "+paymentid);
  
        this.paypalpaymentProcess(paymentid);
       
      }, (error) => {
        // Error or render dialog closed without being successful
        console.log("Error or render dialog closed without being successful"+error);
      });
    }, () => {
      // Error in configuration
      console.log("Error in configuration");
    });
  }, () => {
    // Error in initialization, maybe PayPal isn't supported or something else
    console.log("Error in initialization, maybe PayPal isn't supported or something else");
  });
  
  }
  
     
  paypalpaymentProcess(paymentId){
    let headers = new Headers();
   headers.set('Content-Type','application/x-www-form-urlencoded');
    headers.set('Accept-Language','en_US');
    headers.set('Authorization','Basic '+btoa('AVFarGICtgPeCy3FStVAhzD1IzeIKqE8r2gcFz94W8s--e5FzZqmuJXdZufdyc7usBJfCckEw7SoZGMN:EDNb52iqZ7OdE0pqs1AqL39HCiGVCrHY5qNYYd7f8NKqmrICTWu_Bn5GJlQuPp8gmLGkmQAlVrAW2i_8'));
  let body = "grant_type=client_credentials";
  
  let options = new RequestOptions({method: RequestMethod.Post, headers: headers});
  
  
  this.http.post('https://api.sandbox.paypal.com/v1/oauth2/token',body,options)
  .map(res => res.json())
  .subscribe(data => {
  console.log("accesstoken data "+JSON.stringify(data));
  
  let accesstoken = data.access_token;
  
  this.getPaypalPayerID(accesstoken,paymentId);
  
  })
  
  }
  
  
  getPaypalPayerID(accesstoken,paymentid){
     let headers = new Headers();
     headers.set('Content-Type','application/x-www-form-urlencoded');
     headers.set('Accept-Language','en_US');
     headers.set('Authorization','Bearer '+accesstoken);
     let options = new RequestOptions({method: RequestMethod.Get, headers: headers});
   this.http.get('https://api.sandbox.paypal.com/v1/payments/payment/'+paymentid,options)
   .map(res => res.json())
   .subscribe(data => {
   let payerID = JSON.stringify(data.payer.payer_info.payer_id);
   console.log("payerID "+payerID);
   })
  }
    
  
  // PAYPAL ENDS //

//Offline cart
offlineQuickorder(){  
  this.navCtrl.push(OfflinequickorderPage);
}
//offline cart ends
}
