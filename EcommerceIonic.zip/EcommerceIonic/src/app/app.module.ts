import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { HttpModule } from '@angular/http'; 
import { HttpClientModule } from '@angular/common/http';
import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage, PopoverPage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { MenuForAppPage } from '../pages/menu-for-app/menu-for-app';
import { ProductcategoriesPage } from '../pages/productcategories/productcategories';
import { ProductgridPage } from '../pages/productgrid/productgrid';
import { ProductdetailPage } from '../pages/productdetail/productdetail';
import { LoginPage } from '../pages/login/login';
import { ForgotpasswordPage } from '../pages/forgotpassword/forgotpassword';
import { RegisterPage } from '../pages/register/register';
import { RegistertypePage } from '../pages/registertype/registertype';
import { PhotoenqueryPage } from '../pages/photoenquery/photoenquery';
import { RestProvider } from '../providers/rest/rest';
import { MyprovidersProvider } from '../providers/myproviders/myproviders';
import { MyAccountPage } from '../pages/my-account/my-account';
import { LocationsPage } from '../pages/locations/locations';
import { OrderhistoryPage } from '../pages/orderhistory/orderhistory';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { Toast } from '@ionic-native/toast';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { SearchPage } from '../pages/search/search';
import { HelpPage } from '../pages/help/help';
import { CartPage } from '../pages/cart/cart';
import { SavedcartPage } from '../pages/savedcart/savedcart';
import { SavedcartdetailsPage } from '../pages/savedcartdetails/savedcartdetails';
import { ProductgroupPage } from '../pages/productgroup/productgroup';
import { ProductgroupdetailsPage } from '../pages/productgroupdetails/productgroupdetails';
import { OpenordersPage } from '../pages/openorders/openorders';
import { InAppBrowser } from '@ionic-native/in-app-browser';

//shwetha
import { ChangeshipaddressPage } from '../pages/changeshipaddress/changeshipaddress';
import { OtherappsPage } from '../pages/otherapps/otherapps';

//prem
import { ChangepasswordPage } from '../pages/changepassword/changepassword';
import { AccountdashboardPage } from '../pages/accountdashboard/accountdashboard';
import { RequestforquotePage } from '../pages/requestforquote/requestforquote';

//madhu
import { CheckoutPage } from '../pages/checkout/checkout';
import { SpeechRecognition } from '@ionic-native/speech-recognition';
import { EditcontactinfoPage } from '../pages/editcontactinfo/editcontactinfo';
import { OrderdetailPage } from '../pages/orderdetail/orderdetail';
import { ConfirmorderPage } from '../pages/confirmorder/confirmorder';
import { OrderconfirmationPage } from '../pages/orderconfirmation/orderconfirmation';
import { CheckoutquotePage } from '../pages/checkoutquote/checkoutquote';
import { ReordercartPage } from '../pages/reordercart/reordercart';
import { AngularFireModule } from 'angularfire2';
import { AngularFirestoreModule } from 'angularfire2/firestore';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { Push } from '@ionic-native/push';
import { Firebase } from '@ionic-native/firebase';
import { PayPal } from '@ionic-native/paypal';
import { OfflinequickorderPage } from '../pages/offlinequickorder/offlinequickorder';
import { SearchpopupPage } from '../pages/searchpopup/searchpopup';
import { FilterPage } from '../pages/filter/filter';
import { IonicImageViewerModule } from 'ionic-img-viewer';
import { SubcategoryPage } from '../pages/subcategory/subcategory';
import { TempsubcategoryPage } from '../pages/tempsubcategory/tempsubcategory';
import { BrandsPage } from '../pages/brands/brands';
import { ManufacturerPage } from '../pages/manufacturer/manufacturer';
import { MyHeaderComponent } from '../components/my-header/my-header';
import { Overslide } from '../directives/overslide/overslide';
// import { PhotoViewer } from '@ionic-native/photo-viewer';

const firebaseAuth = {
apiKey: "AIzaSyB4CtPC9l7_mQIaq6RdplKJYKtUsVW6Msw",
authDomain: "myionic-cddd5.firebaseapp.com",
databaseURL: "https://myionic-cddd5.firebaseio.com",
projectId: "myionic-cddd5",
storageBucket: "myionic-cddd5.appspot.com",
messagingSenderId: "374083995684"
};
@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    MenuForAppPage,
    ProductcategoriesPage,
    ProductgridPage,
    ProductdetailPage,
    LoginPage,
    ForgotpasswordPage,
    RegisterPage,
    RegistertypePage,
    MyAccountPage,
    PhotoenqueryPage,
    LocationsPage,
    SearchPage,
    HelpPage,
    CartPage,
    SavedcartPage,
    SavedcartdetailsPage,
    ProductgroupPage,
    ProductgroupdetailsPage,
    OpenordersPage,
    ChangeshipaddressPage,
    OtherappsPage,ChangepasswordPage,
    AccountdashboardPage,
    RequestforquotePage,
    CheckoutPage,
    OrderhistoryPage,
    EditcontactinfoPage,
    OrderdetailPage,
    ConfirmorderPage,
    OrderconfirmationPage,
    CheckoutquotePage,
    ReordercartPage,
    PopoverPage,
    OfflinequickorderPage,
    SearchpopupPage,
    FilterPage,
    SubcategoryPage,
    TempsubcategoryPage,
    BrandsPage,
    ManufacturerPage,
    MyHeaderComponent,
    Overslide
    ],
  imports: [
    HttpModule,
    BrowserModule,
    HttpClientModule,
    AngularFireModule.initializeApp(firebaseAuth),
    AngularFireAuthModule,
    AngularFirestoreModule,
    IonicImageViewerModule,
        IonicModule.forRoot(MyApp,{
      backButtonText: '',
      menuType: 'push',
      platforms: {
        ios: {
          menuType: 'overlay',
        },
        android:{
          menuType: 'overlay',
        }
      }
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    MenuForAppPage,
    ProductcategoriesPage,
    ProductgridPage,
    ProductdetailPage,
    LoginPage,
    ForgotpasswordPage,
    RegisterPage,
    RegistertypePage,
    MyAccountPage,
    PhotoenqueryPage,
    LocationsPage,
    SearchPage,
    HelpPage,
    CartPage,
    SavedcartPage,
    SavedcartdetailsPage,
    ProductgroupPage,
    ProductgroupdetailsPage,
    OpenordersPage,
    ChangeshipaddressPage,
    OtherappsPage,ChangepasswordPage,
    AccountdashboardPage,
    RequestforquotePage,
    CheckoutPage,
    OrderhistoryPage,
    EditcontactinfoPage,
    OrderdetailPage,
    ConfirmorderPage,
    OrderconfirmationPage,
    CheckoutquotePage,
    ReordercartPage,
    PopoverPage,
    OfflinequickorderPage,
    SearchpopupPage,
    FilterPage,
    SubcategoryPage,
    TempsubcategoryPage,
    BrandsPage,
    ManufacturerPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    RestProvider,
    RestProvider,
    Camera,
    InAppBrowser,
    MyprovidersProvider,
    BarcodeScanner,
    SpeechRecognition,
    Push,
    Firebase,
    PayPal,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ],
})
export class AppModule {}
