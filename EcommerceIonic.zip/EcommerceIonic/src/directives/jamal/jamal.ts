import { Directive } from '@angular/core';

/**
 * Generated class for the JamalDirective directive.
 *
 * See https://angular.io/api/core/Directive for more info on Angular
 * Directives.
 */
@Directive({
  selector: '[jamal]' // Attribute selector
})
export class JamalDirective {

  constructor() {
    console.log('Hello JamalDirective Directive');
  }

}
