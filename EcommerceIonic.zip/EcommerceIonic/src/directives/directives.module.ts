import { NgModule } from '@angular/core';
import { JamalDirective } from './jamal/jamal';
@NgModule({
	declarations: [JamalDirective],
	imports: [],
	exports: [JamalDirective]
})
export class DirectivesModule {}
